## Geospatial Analysis with Excel

[![Geospatial analysis with Excel](https://i.ytimg.com/vi_webp/49LjxNvxyVs/sddefault.webp)

> 📘 **Image Description:** Certainly! Based on the image you sent, here's the study-related content I can discern:

**Main Topic:**

The image seems to depict a geographical data visualization, likely related to urban planning, demographics, or resource distribution within a city. The context is New York.

**Visual elements**:

*   **3D Map:** The underlying structure is a map, presumably of a city and its surrounding areas.
*   **Colored Bars:** There are numerous vertical bars (some green, some yellow) protruding from the map.
*   The bars appear to be positioned over specific locations on the map.
*   The height of the bars likely represents a value associated with that location (e.g., population density, building height, income level, resource availability).
*   There is a base map containing features such as roads, rivers, and buildings.
*   Data is grouped into zones.
*   **Esri Copyright**: this suggests that the map was created with Esri software.

**Possible Interpretations and Related Study Areas:**

*   **Population density:** The height of the bars might represent the number of people living in each area.
*   **Income or Economic Data:** The bars could represent average income, property values, or other economic indicators.
*   **Resource allocation:** If the map shows the distribution of resources like schools, hospitals, or parks, the bars could indicate the availability or accessibility of these resources.
*   **Land Use:** The base map, combined with the bar heights, might be used to analyze land use patterns (e.g., residential, commercial, industrial).
*   **Environmental Analysis:** The bars could represent pollution levels, green space area, or other environmental factors.

If you provide more context or details about what the visualization is meant to convey, I can offer a more specific interpretation.
](https://youtu.be/49LjxNvxyVs)

You'll learn how to create a data-driven story about coffee shop coverage in Manhattan, covering:

- **Data Collection**: Collect and scrape data for coffee shop locations and census population from various sources.
- **Data Processing**: Use Python libraries like geopandas for merging population data with geographic maps.
- **Map Creation**: Generate coverage maps using tools like QGIS and Excel to visualize coffee shop distribution and population impact.
- **Visualization**: Create physical, Power BI, and video visualizations to present the data effectively.
- **Storytelling**: Craft a narrative around coffee shop competition, including strategic insights and potential market changes.

Here are links that explain how the video was made:

- [The Making of the Manhattan Coffee Kings](https://blog.gramener.com/the-making-of-manhattans-coffee-kings/)
- [Shaping and merging maps](https://blog.gramener.com/shaping-and-merging-maps/)
- [Visualizing data on 3D maps](https://blog.gramener.com/visualizing-data-on-3d-maps/)
- [Physical and digital 3D maps](https://blog.gramener.com/physical-and-digital-3d-maps/)
