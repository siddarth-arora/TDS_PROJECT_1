## Narratives with Comics

[![Comic narratives with Google Sheets & Comicgen](https://i.ytimg.com/vi/HZDqCQBpHGI/sddefault.jpg)

> 📘 **Image Description:** The image shows a webpage titled "Comicgen: Comic Creator" with the URL gramener.com/comicgen/v1/#name=dey&text=Comic+speech+bubble+text&width=100&height=100&align=center&font-family=Architects+Daughte... The content on the webpage includes the following study-related elements:

1.  **Topic:** Data Storytelling

2.  **Text:** "Interested in data storytelling? Come join the #ComicgenFriday community."

3.  **Button:** "Data Comicgen Awards"

In essence, the image is promoting the use of comic storytelling for data visualization and communication, inviting users to join a community focused on this approach.
](https://youtu.be/HZDqCQBpHGI)

- [Sample sheet](https://docs.google.com/spreadsheets/d/1b0DOfJnnx6MFcN955YqRqYafLb8XrH-zqtLaK2h5kkc/edit#gid=1534638946)
