# Data Preparation

Data preparation is crucial because raw data is rarely perfect.

It often contains errors, inconsistencies, or missing values. For example, marks data may have 'NA' or 'absent' for non-attendees, which you need to handle.

This section teaches you how to clean up data, convert it to different formats, aggregate it if required, and get a feel for the data before you analyze.

Here are links used in the video:

- [Presentation used in the video](https://docs.google.com/presentation/d/1Gb0QnPUN1YOwM_O5EqDdXUdL-5Azp1Tf/view)
- [Scraping assembly elections - Notebook](https://colab.research.google.com/drive/1SP8yVxzmofQO48-yXF3rujqWk2iM0KSl)
- [Assembly election results (CSV)](https://github.com/datameet/india-election-data/blob/master/assembly-elections/assembly.csv)
- [`pdftotext` software](https://www.xpdfreader.com/pdftotext-man.html)
- [OpenRefine software](https://openrefine.org)
- [The most persistent party](https://gramener.com/election/parliament#story.ddp)
- [TN assembly election cartogram](https://gramener.com/election/cartogram?ST_NAME=Tamil%20Nadu)

[![Data Preparation - Introduction](https://i.ytimg.com/vi_webp/dF3zchJJKqk/sddefault.webp)

> 📘 **Image Description:** Here is the study-related content of the image:

**Topic:** Likely some form of demographic analysis, perhaps related to election results or population trends in specific locations over time.

**Headings:**
*   **Row Labels:** (Column A) Lists place names such as "AFZALPUR," "ALAND," "ANEKAL," etc.
*   **Years:** Columns B through N represent years: 1957, 1962, 1967, 1972, 1978, 1983, 1985, 1989, 1994, 1999, 2004, 2008, 2013.

**Content:**
*   The table contains numerical data associated with each location for different years. The numbers' significance can't be determined without more context.

**Formulas:**
*The image does not contain any identifiable formulas*
](https://youtu.be/dF3zchJJKqk)
