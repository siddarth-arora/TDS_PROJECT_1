## Visualizing Network Data with Kumu

[![Visualizing network data with Kumu](https://i.ytimg.com/vi_webp/OndB17bigkc/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

*   **Main Topic:** Sparse Matrices

*   **Headings/Concepts:**

    *   "total number of nonzeros above row j. The last element is NNZ, i.e., the fictitious index in V immediately after the last valid index NNZ - 1."
    *   "assuming a zero-indexed language"
    *   "To extract a row, we first define:"
    *   "Then we take slices from V and COL_INDEX starting at row_start and ending at row_end."
    *   CSR Representation

*   **Formulas/Representations:**

    *   Matrix examples (4x4 and 5x6) showing sparse structures.
    *   `V = [5 8 3 6]`
    *   `COL_INDEX = [0 1 2 1]`
    *   `ROW_INDEX = [0 1 2 3 4]`
    *   `row_start = ROW_INDEX[row]`
    *   `row_end = ROW_INDEX[row + 1]`

*   **Explanation:**
    The content discusses the concept of sparse matrices and how to represent and extract data from them efficiently using techniques like CSR (Compressed Sparse Row) representation. It provides examples, formulas, and descriptions to illustrate these concepts.
](https://youtu.be/OndB17bigkc)

- [Kumu](https://kumu.io)
- [IMDB data](https://developer.imdb.com/non-commercial-datasets/)
- [Jupyter Notebook](https://colab.research.google.com/drive/1CHR68fw7lZC9H2JtVW4LXpUvNwfM_VE-?usp=sharing)

[![Network analysis – filtering by year](https://i.ytimg.com/vi_webp/oi4fDzqsCes/sddefault.webp)

> 📘 **Image Description:** Based on the image, here's a breakdown of the study-related content:

*   **Main Topic:** Data analysis or data preparation, likely using Python and a library like Pandas. This is inferred from the "DataPrepForKum.ipynb" filename and the code snippets related to data manipulation.

*   **Headings/Column Names:**
    *   `titleType`
    *   `primaryTitle`
    *   `shortTitle`
    *   `startYear`

*   **Data Structures:**
    *   Dataframe named `title.dtypes` shows the types of the columns (`object` as likely representing strings)
    *   Dataframe `title.startYear` containing column with same name and boolean values.

*   **Code Snippets:**
    *   `[6] title['startYear'] > '1900'` :  This is a boolean filter.  It's selecting rows where the `startYear` column is greater than '1900', likely used to filter data and create boolean mask for rows with `startYear` later than 1900.

In summary, the content shows data wrangling using Pandas with filtering, potentially on a dataset of movies, TV shows, or similar media. The goal is likely to prepare data for further analysis.
](https://youtu.be/oi4fDzqsCes)
