## Data Transformation in Excel

[![Data transformation in Excel](https://i.ytimg.com/vi_webp/gR2IY5Naja0/sddefault.webp)

> 📘 **Image Description:** Here's a description of the study-related content visible in the image:

*   **Main Topic:** The data in the Excel sheet appears to be related to urban geography or urban planning, focusing on cities and their characteristics.

*   **Headings:** The columns are labeled with the following headers, likely related to urban areas:

    *   "Site(s)"
    *   "Country"
    *   "Urban population (2018)"
    *   "City proper (s) definion(s)"
    *   "City_Proper_define (long)"
    *   "City proper population (2018)"
    *   "City proper area (km²)"
    *   "City proper density (per km²)"
    *   "Metropolitan proper definition"
    *   "Metropolitan population (2018)"
    *   "Metropolitan area (km²)"
    *   "Metropolitan Density (per km²)"
    *   "Urban area (1) population (2018)"
    *   "Urban area (1) area (km²)"
    *   "Urban area (1) density (km²)"
*   **Formulas:** I can't identify formulas.
*   **Data:** The data is a collection of cities and their related information (population, area, density) grouped by country.

In essence, the spreadsheet seems to be a dataset of cities and their urban characteristics, probably for comparative analysis.
](https://youtu.be/gR2IY5Naja0)

You'll learn data transformation techniques in Excel, covering:

- **Calculating Ratios**: Compute metro area to city area and metro population to city population ratios.
- **Using Pivot Tables**: Create pivot tables to aggregate data and identify outliers.
- **Filtering Data**: Apply filters in pivot tables to analyze specific subsets of data.
- **Counting Data Occurrences**: Use pivot tables to count the frequency of specific entries.
- **Creating Charts**: Generate charts from pivot table data to visualize distributions and outliers.

Here are links used in the video:

- [List of Largest Cities Excel file](https://docs.google.com/spreadsheets/d/1jl8tHGoxmIba4J78aJVfT9jtZv7lfCbV/view)
