## Scraping: Live Sessions

[![Intro to Web scraping and HTML](https://i.ytimg.com/vi_webp/cAriusuJsmw/sddefault.webp)

> 📘 **Image Description:** The image shows a webpage from Amazon India, displaying search results for "Smartphones under 20000". The main topic is shopping for smartphones within a specific price range. There are no headings, formulas, or equations present. The image shows the search bar with the query "Smartphones under 20000", filters for delivery day, category, customer review, and brand. Results for "Tecno Pop 8" smartphones are prominently displayed.
](https://youtu.be/cAriusuJsmw)

Fundamentals of web scraping with urllib and BeautifulSoup

[![Fundamentals of web scraping with urllib and BeautifulSoup](https://i.ytimg.com/vi_webp/I3auyTYORTs/sddefault.webp)

> 📘 **Image Description:** Based on the information in the image, the study-related content appears to be within a Google Meet session. The person named "Amit Kumar Gupta" is presenting.

There are no visible headings, formulas, or a clear main topic displayed on the screen within the image itself. The screen is showing a warning to avoid an "infinity mirror" effect when presenting.
](https://youtu.be/I3auyTYORTs)

Intermediate web scraping use of cookies

[![Intermediate web scraping use of cookies](https://i.ytimg.com/vi_webp/DryMIxMf3VU/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

**Main Topic:**

*   Based on the browser tabs, the study content seems to be related to "Population by Country." This is inferred from the open tab labeled "Population by Cou...".
*   The other open tab is an untitled Google Colaboratory notebook (Untitled2.ipynb), which suggests a coding or data analysis element to this.

**Google Colaboratory Notebook:**

*   **Interface:** The right side of the image shows a Google Colaboratory notebook, a platform used for coding, data analysis, and machine learning.
*   **Elements:** The Colab interface includes elements like:
    *   "+ Code": To add code cells to the notebook.
    *   "+ Text": To add text or Markdown cells for documentation or explanations.
    *   "Connect": A button to connect the notebook to a runtime environment for executing the code.
*   **Potential Use:** This suggests that the study involves coding/data analysis and potentially visualization of population data. The notebook may be used to analyze population data, create visualizations, or perform other related tasks.

**Google Meet:**

*   The left side shows a Google Meet interface.
*   It appears that the user is presenting or sharing their screen ("Stop presenting" button).
*   The "People" window shows a list of contributors and may be part of a collaborative effort to learn the concepts.

**Overall:**

The image suggests a study session on population data analysis, likely involving coding and data visualization using Google Colaboratory. There is also likely a presentation or teaching aspect involved (Google Meet screen sharing), and a collaborative component due to the presence of multiple contributors.
](https://youtu.be/DryMIxMf3VU)

XML intro and scraping

[![XML intro and scraping](https://i.ytimg.com/vi_webp/8S_jvsjtaYg/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

**Main Topics:**

*   **XML (Extensible Markup Language):**  Mentioned in browser tabs "XML Examples" and "Best XML Viewer". The URL "w3schools.com/xml/note" also confirms this.
*   **Python:** Shown with the "Python 24" and "Python Textbook" buttons.
*   **TDS (Tax Deducted at Source):** Reflected in the buttons labelled “TDS Discourse,” “Jan 2024 – TDS,” and “Jan 2003 - TDS - ITM.”
*   **App Dev (Application Development):** Seen in the button labeled "App Dev Project Doc...".

**Content Types/Resources:**

*   XML Examples (likely code snippets or tutorials)
*   Python Textbook (suggests a learning resource)
*   TDS Discourse (Could refer to notes, discussion, or lectures)
*   App Dev Project Doc (Indicates project documentation for an app development project).

**Possible Specifics:**

*   "Python 24" may indicate a module of study
*   "Jan 2004-TDS" and "Jan 2003 - TDS - ITM" are most likely related to study on the Tax Deducted at Source for those specific years.

Overall, the image shows someone studying several technical topics including XML, Python programming, Tax Deducted at Source (TDS), and Application Development.
](https://youtu.be/8S_jvsjtaYg)
