# Data visualization

[![Data visualization](https://i.ytimg.com/vi_webp/XkxRDql00UU/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

*   **Main Topic:**  The slide is titled "Design the output" which suggests the context is related to data visualization or reporting.

*   **Headings:** The slide has two columns labeled:
    *   "General"
    *   "Specialized"

*   **Content:**
    *   Under "General" it lists data visualization/analysis tools like:
        *   Excel
        *   Google Data Studio
        *   Power BI
        *   Tableau
    *   Under "Specialized" it lists tools such as:
        *   Excel (VBA)
        *   Flourish Studio
        *   Kumu
        *   QGIS

The slide appears to be categorizing software based on how generally applicable or specialized they are for designing outputs (presumably reports, visualizations, etc.).
](https://youtu.be/XkxRDql00UU)
