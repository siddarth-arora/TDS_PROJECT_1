## Geospatial Analysis with QGIS

[![Geospatial analysis with QGIS](https://i.ytimg.com/vi_webp/tJhehs0o-ik/sddefault.webp)

> 📘 **Image Description:** Based on the image, the study-related content appears to focus on Geographic Information Systems (GIS) and spatial data analysis, specifically using the QGIS software.

*   **Main Topic:**  GIS data processing and visualization of the administrative boundaries of South Sudan.
*   **Headings:** The image shows several interface elements of the QGIS software. These include:
    *   File Browser, showing a folder structure with shapefiles (`.shp`) and CSV files related to South Sudan administrative boundaries (named like "SDN\_adm0.shp", "SDN\_adm1.shp", etc.).
    *   Layers Panel, listing layers such as "SDN\_adm0", "SDN\_adm1", "SDN\_adm2", and "SDN\_adm3".
    *   A toolbar with icons representing various GIS functions (e.g., zoom, pan, identify features).
*   **Formulas:** There are no explicit formulas visible.
*   **Other Observable Content:**
    *   The main map area displays a red shaded map of what appears to be South Sudan.  The different colored regions represent administrative boundaries (likely representing "SDN\_adm3"). The layers panel show it's most detailed boundary level.
    *   The files list "SDN\_adm.zip" suggests that the administrative boundary data might be downloaded from some source.
](https://youtu.be/tJhehs0o-ik)

You'll learn how to use QGIS for geographic data processing, covering:

- **Shapefiles and KML Files**: Create and manage shapefiles and KML files for storing and analyzing geographic information.
- **Downloading QGIS**: Install QGIS on different operating systems and familiarize yourself with its interface.
- **Geospatial Data**: Access and utilize shapefiles from sources like Diva-GIS and integrate them into QGIS projects.
- **Creating Custom Shapefiles**: Learn how to create custom shapefiles when existing ones are unavailable, including creating a shapefile for South Sudan.
- **Editing and Visualization**: Use QGIS tools to edit shapefiles, add attributes, and visualize geographic data with various styling and labeling options.
- **Exporting Data**: Export shapefiles or KML files for use in other applications, such as Google Earth.

Here are links used in the video:

- [QGIS Project](https://www.qgis.org/en/site/)
- [Shapefile Data](https://www.diva-gis.org/gdata)
