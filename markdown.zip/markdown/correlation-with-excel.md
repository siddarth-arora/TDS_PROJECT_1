## Correlation with Excel

[![Correlation with Excel](https://i.ytimg.com/vi_webp/lXHCyhO7DmY/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

*   **Main Topic:** The image appears to be analyzing the relationship between new COVID-19 cases and new deaths in Brazil during January and February 2021.
*   **Spreadsheet Data:** The Excel sheet contains the following data:
    *   **Column A:** Country code (BRA)
    *   **Column B:** Country Name (Brazil)
    *   **Column C:** Date
    *   **Column D:** Possibly total cases
    *   **Column E:** new_deaths
    *   **Column F:** new_vaccinations
    *   **Column H:** 'new\_deaths' (likely the daily number of new deaths due to COVID-19)
    *   **Column I:** (value 0.8845316008) This is likely a regression parameter or some other derived statistical value related to the analysis.
    *   **Column J:** 'new\_vaccinations' (likely the daily number of new vaccinations administered)
    *   **Column K:** (value 0.288554403, and 0.235266388) These are likely regression parameters or some other derived statistical values related to the analysis.
*   **Chart:**
    *   The chart is a scatter plot titled "new\_cases vs new\_deaths".
    *   It shows a trendline, suggesting a positive correlation between the two variables.
*   **Trendline Options:** The "Format Trendline" panel is open, indicating that the user is likely adjusting the properties of the trendline on the chart (e.g., color, transparency, width).
](https://youtu.be/lXHCyhO7DmY)

You'll learn to calculate and interpret correlations using Excel, covering:

- **Enabling the Data Analysis Tool Pack**: Steps to enable the Excel data analysis tool pack.
- **Correlation Analysis**: Understanding statistical association between variables.
- **Creating a Correlation Matrix**: Steps to generate and interpret a correlation matrix.
- **Scatterplots and Trendlines**: Plotting data and adding trend lines to visualize correlations.
- **Analyzing Results**: Comparing correlation coefficients and understanding their implications.
- **Insights and Further Analysis**: Interpreting scatterplots and planning further analysis for deeper insights.

Here are the links used in the video:

- [Understand correlation](https://www.khanacademy.org/math/ap-statistics/bivariate-data-ap/correlation-coefficient-r/v/correlation-coefficient-intuition-examples)
- [COVID-19 vaccinations data explorer - Website](https://ourworldindata.org/covid-vaccinations?country=OWID_WRL)
- [COVID-19 vaccinations - Correlations Excel file](https://docs.google.com/spreadsheets/d/1_vQF2i5ubKmHQMBqoTwsu6AlevWsQtTD/view#gid=790744269)
