# Archived content

## Videos

### IITM BS Degree - Diploma Level Orientation

[![IITM BS Degree - Diploma Level Orientation, May 2022](https://img.youtube.com/vi_webp/Dj7X0bQRJSs/sddefault.webp)

> 📘 **Image Description:** Based on the image, here's what I can gather about the study-related content:

*   **Context:** The image appears to be a screenshot of a Webex meeting hosted by IIT Madras - NPTEL. This suggests the meeting is likely related to an online course or educational program.
*   **Books:** There are a couple of books visible on the desk in front of the man on the right. The visible title on one of the books looks like it says 'Ecology and Beyond'.
*   **Main Topic:** Based on the presence of the book 'Ecology and Beyond', the meeting might be related to ecology, environmental science, or a similar field.
*   **Formulas/Headings:** There are no formulas or headings visible in the image.

It's difficult to provide more specific details without additional information. However, the clues point towards an online course or lecture related to Ecology.
](https://youtu.be/Dj7X0bQRJSs)

### Tools in Data Science Orientation

[![TDS Orientation, May 2022](https://img.youtube.com/vi_webp/_c_aFQ0ObLo/sddefault.webp)

> 📘 **Image Description:** The image shows the word "Dixon" in the center of the screen. It seems likely that this is someone's name, and that the image is a screenshot from a Zoom meeting. Since the only text on the screen is a name, it is not possible to determine what the main topic of the meeting is.
](https://youtu.be/_c_aFQ0ObLo?t=4186)

### Tools in Data Science Live Sessions

[![TDS YouTube channel for live sessions](https://img.youtube.com/vi_webp/MQgOy5RNNz0/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

**Main Topic:** Data Sourcing/Getting the Data

**Content from the slides/presentation:**

*   **Heading:** TOOLS IN DATA SCIENCE
*   **Subheading:** Get the Data Introduction
*   **Instructor:** S Anand
*   A paragraph stating that before doing any kind of data science, you need to get the data to be able to analyze, visualize, narrate, and deploy it. And what the module will cover is how to get the data.

**Content from the Notes:**

*   **ROE:** Open exam, including concepts like internet, GPT, and LLM. Syllabus content includes everything, roughly weeks 2-5.
*   **Scraping:**
    *   HTML
        *   Live site: Wikipedia
        *   HTML local file: HTML code in drive
        *   Simple: no login
        *   Authentication: MovieLens Cookies
    *   XML Files
](https://www.youtube.com/@se-lr5ff)

### Tools in Data Science Playlist

[![Tools in Data Science Course Playlist , but only 17 videos](https://i.ytimg.com/vi_webp/3OeMOb7gByE/sddefault.webp)

> 📘 **Image Description:** The image appears to be the title screen for a presentation or video about data science. Here's a breakdown:

*   **Main Title:** "Discover the Data"
*   **Subtitle:** "Tools in Data Science"

There aren't any explicit formulas visible, but the background contains visualizations commonly used in data analysis, such as bar charts, pie charts, line graphs, and diagrams relating to ideas and business decisions.
](https://www.youtube.com/playlist?list=PLZ2ps__7DhBZEOxUBCkv61WHOu8m7ObpE)

[Tools in Data Science Course Playlist, 66 videos](https://youtube.com/playlist?list=PLZ2ps__7DhBZJ2q_hd8ZbDRgOJlB0CZLw&feature=shared)

## Optional: Parse & clean PDF files with Tabula

[![Parse & clean PDF files with Tabula](https://i.ytimg.com/vi_webp/IEusn9HB1sc/sddefault.webp)

> 📘 **Image Description:** Certainly! Here's the breakdown of the study-related content in the image:

**Main Topic:**

*   Data Journalism

**Heading:**

*   "Getting Started With Data Journalism"

**Content Indicators:**

*   The image shows an Adobe PDF file being converted to an Excel file. This is a key element in data journalism, where data is often extracted from PDF documents and organized in spreadsheets for analysis and reporting.
*   The visual of many people working on laptops suggests a workshop or training session on the topic.
](https://youtu.be/IEusn9HB1sc)

- [Tabula documentation](https://tabula-py.readthedocs.io/en/latest/)

- Learn about the [`io` package](https://pymotw.com/3/io/), [reference](https://docs.python.org/3/library/io.html) and [video](https://youtu.be/cIaOisyd7lE)
- Learn about the [`os` package](https://pymotw.com/3/os/index.html), [reference](https://docs.python.org/3/library/os.html) and [video](https://youtu.be/tJxcKyFMTGo)

[![Wikipedia data with Wikimedia Python library](https://i.ytimg.com/vi_webp/b6puvm-QEY0/sddefault.webp)

> 📘 **Image Description:** Here is a description of the study-related content in the image:

*   **Main Topic:** Getting Data from Wikimedia.
*   **Course:** Tools in Data Science.
*   **Instructor:** Anand S.
*   **Tutorial Instructor:** Dibu Philip.
*   **Institution:** IIT Madras (Indian Institute of Technology Madras) Online Degree program.
](https://youtu.be/b6puvm-QEY0)

- Wikipedia Library - [Notebook](https://colab.research.google.com/drive/1UZky5JdOn2oMYIkls23WefTaT8VinYyg)
- Learn about the [`wikipedia` package](https://wikipedia.readthedocs.io/en/latest/)

## Image labelling with chess pieces

[![Image labelling with chess pieces](https://i.ytimg.com/vi_webp/OTRamjRb7P4/sddefault.webp)

> 📘 **Image Description:** Based on the image, the study-related content appears to be focused on **image classification** specifically related to **chess pieces**.

Here's a breakdown:

*   **Main Topic:** Image classification of chess pieces, particularly the "Bishop".
*   **Headings:** The file path in the file explorer shows "Image\_Classification" and "Chessman-image-dataset". Within the folder "Chessman-image-dataset" there are subfolders: "Chess" with subfolders "Bishop", "King", "Knight", "Pawn", "Queen", "Rook".
*   **Image Content:** The main window displays numerous images, all of which appear to be pictures of Bishop chess pieces. Each image is labeled with a numerical identifier.

In summary, the content suggests a project involving classifying images of chess pieces, with the visible portion focusing on images of the "Bishop" piece for use in a classification task.
](https://youtu.be/OTRamjRb7P4)

- [Image dataset](https://www.kaggle.com/datasets/niteshfre/chessman-image-dataset)
- [Chess Pawns Excel file](https://docs.google.com/spreadsheets/d/156zEzw4al4Onx5IGPvhF8GbEj1TQ6Bqz/edit#gid=1998348575)
- [Jupyter Notebook](https://colab.research.google.com/drive/1xWILF9ifT2ifTYv4EXPUiB58Ts0-O9Bo?usp=sharing)
- Learn about the [PIL module](https://pypi.org/project/pillow/), [reference](https://pillow.readthedocs.io/en/stable/) and [video](https://youtu.be/dkp4wUhCwR4)
- Learn about the [BeautifulSoup module](https://beautiful-soup-4.readthedocs.io/en/latest/#quick-start) and [video](https://youtu.be/XVv6mJpFOb0)
- Learn about the [io module](https://pymotw.com/3/io/), [reference](https://docs.python.org/3/library/io.html) and [video](https://youtu.be/cIaOisyd7lE)

## Forecasting time series with Python

[![Forecasting time series with Python](https://i.ytimg.com/vi_webp/aedA2javxvE/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content visible in the image:

*   **Main Topic:** The title of the notebook is "Covid19Forecasting.ipynb", suggesting the topic is forecasting COVID-19 trends.

*   **Plot:** There's a graph showing trends over time (from 2021-02 to 2021-07). Two lines are displayed:
    *   Rolling 15 day mean
    *   Rolling 20 day mean

*   **Code Snippets (Python):**
    *   `data['moving_avg_5day'] = rolling_mean5`
    *   `data['moving_avg_10day'] = rolling_mean10`
    *   `data['moving_avg_15day'] = rolling_mean15`
    *   `data['moving_avg_20day'] = rolling_mean20`
    *   `data.head()`
        (These lines appear to be assigning rolling means to new columns in a Pandas DataFrame named "data".)

    *   `data.dropna(inplace=True)`
        (This line drops rows with missing values from the data)

    *   `autocorrelation_plot(data['new_cases'])`
        `plt.show()`
        (This section plots the autocorrelation of the "new_cases" column and displays the plot.)

    *   `from statsmodels.graphics.tsaplots import plot_acf, plot_pacf`
        `import statsmodels.api as sm`
        (This imports specific functions for plotting autocorrelation and partial autocorrelation functions from the statsmodels library, along with importing the statsmodels API under the alias `sm`.)

In summary, the image shows a Python notebook (likely using Google Colab) that's analyzing and forecasting COVID-19 data, focusing on rolling averages, data cleaning (handling missing values), and autocorrelation analysis. The use of `statsmodels` suggests more advanced time series analysis is being considered.
](https://youtu.be/aedA2javxvE)

- [Jupyter Notebook](https://colab.research.google.com/drive/1J62K0GG56ZNzq981AOTGwH_oA9w4RAYA?usp=sharing)
- [Understand time series modeling, moving averages and ARIMA](https://www.youtube.com/playlist?list=PLjwX9KFWtvNnOc4HtsvaDf1XYG3O5bv5s)
- Learn about the [pandas module](https://youtu.be/vmEHCJofslg) and [video](https://youtu.be/vmEHCJofslg)
- Learn about the [matplotlib module](https://matplotlib.org/stable/users/explain/quick_start.html) and [video](https://youtu.be/3Xc3CA655Y4)
- Learn about the [statsmodels module](https://www.statsmodels.org/stable/index.html) and [video](https://youtu.be/2BdfjqyWj3c)

## Data classification with Python

[![Data classification with Python](https://i.ytimg.com/vi_webp/XsOihX38Bg0/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

*   **Main Topic:** Credit Card Decision Trees. This is evident from the notebook title "Credit\_Card\_Decision\_Tree.ipynb".
*   **Code Snippets:**
    *   `sns.scatterplot(x='ID', y='CNT_CHILDREN', data=df, alpha=0.5, color='orange')` etc., indicating the creation of scatter plots using the seaborn library.
    *   `create_subplot(axes.subplots(at default values))` suggests the creation of multiple subplots in a single figure.
    *   `df.shape` is used to get the dimensions of the dataframe.
*   **Data Preprocessing:**
    *   **Heading:** "Removing Outliers using IQR Technique".
    *   **Formulas/Calculations:**
        *   `q_hi = df['AMT_INCOME_TOTAL'].quantile(0.75)`: Calculates the 75th percentile (Q3) of the 'AMT\_INCOME\_TOTAL' column.
        *   `q_low = df['AMT_INCOME_TOTAL'].quantile(0.25)`: Calculates the 25th percentile (Q1) of the 'AMT\_INCOME\_TOTAL' column.
        *   `iqr = q_hi - q_low`: Calculates the Interquartile Range (IQR).
        *   `lower_range = q_low - 1.5 * iqr`: Calculates the lower bound for outlier detection.
        *   `upper_range = q_hi + 1.5 * iqr`: Calculates the upper bound for outlier detection.
        *   `df = df[ (df['AMT_INCOME_TOTAL'] > lower_range) & (df['AMT_INCOME_TOTAL'] < upper_range) ]`: Filters the DataFrame to remove outliers from 'AMT\_INCOME\_TOTAL' column.
        *   `df = df[df['CNT_CHILDREN'] < 9 ]`: Removes rows where the number of children is greater than or equal to 9.
*   **Data Visualization:**
    *   The images show scatter plots where the x-axis is likely "ID" and the y-axis represents different features such as "CNT\_CHILDREN", "AMT\_INCOME\_TOTAL", "CNT\_FAM\_MEMBERS", and others.

In summary, the content covers data preprocessing (outlier removal) and data visualization (scatter plots) as steps toward building a credit card decision tree model.
](https://youtu.be/XsOihX38Bg0)

- [Jupyter Notebook](https://colab.research.google.com/drive/1aW_sXdYK1UE9AA6TizQqlYTisFftn7T8?usp=sharing)
- [Understand machine learning](https://youtu.be/5q87K1WaoFI)
- [Understand decision trees](https://youtu.be/tNa99PG8hR8)
- Learn about the [pandas module](https://pandas.pydata.org/pandas-docs/stable/user_guide/10min.html) and [video](https://youtu.be/vmEHCJofslg)
- Learn about the [scikit-learn module](https://scikit-learn.org/stable/tutorial/basic/tutorial.html) and [video](https://youtu.be/pqNCD_5r0IU)
- Learn about the [matplotlib module](https://matplotlib.org/stable/users/explain/quick_start.html) and [video](https://youtu.be/3Xc3CA655Y4)

## Optional: R, RStudio and Rattle

R is a language and environment for statistical computing and graphics. It is open source and extremely popular for statistical analysis. In recent years, Python has become the de facto standard for data modeling. However, R still plays an important role for many analysts.

- [Getting started with R and RStudio](https://youtu.be/lVKMsaWju8w)
- [Learn about R](https://cran.r-project.org/manuals.html)
- [Learn about RStudio - an IDE for R](https://posit.co/products/open-source/rstudio/)
- [Learn about Rattle - a GUI for R](https://rattle.togaware.com)
- [Video: Rattle for Data Mining](https://youtu.be/OBilaZZpvGs)

## Automate machine learning with PyCaret

[![Automate machine learning with PyCaret](https://i.ytimg.com/vi_webp/WMUt7NOJGbo/sddefault.webp)

> 📘 **Image Description:** The image shows code and a data table in a Jupyter Notebook environment, likely within Google Colab.

Here's a breakdown of the study-related content:

**Main Topic:**  The content appears related to Machine Learning, specifically data preprocessing and feature selection for model training.

**Code Snippets:**

*   The code `training_data = get_config(variable='a_train')` suggests that the code is loading training data from a configuration file or variable.

**Data Table:**

The data table is labeled "training\_data" and includes the following columns (likely features for a machine learning model):

*   ProdNoWK (likely product number week)
*   SpecialDW1\_1
*   PriceWK
*   SpecialID1\_1
*   StoreID\_2
*   DiscCh
*   SalePriceDW
*   ImpulseCh
*   SalePriceWK
*   ListPriceDiff
*   Store2\_Res
*   S\_US15
*   WkdPurchse
*   PriceDiff
*   PriceSplt
*   Store1\_Res
*   StoreID1\_3

The data table shows numerical values for each feature. This is typical for training a machine learning model.

**Feature Selection Parameters:**

There is also a section with feature selection parameters set:

*   Feature Selection = True
*   Feature Selection Threshold = 0.899
*   Feature Selector = False
*   Feature Interaction = False
*   Fix Imbalance = False

This indicates the study involves feature selection to choose the most relevant features for the model, and they are using a threshold of 0.899 for some selection process.

**In summary, the image captures a step in a machine learning workflow where training data is loaded, feature selection is configured, and data is being examined, likely in preparation for model training.**
](https://youtu.be/WMUt7NOJGbo)

- [Jupyter Notebook](https://colab.research.google.com/drive/1-gHL2lEEuKRFP40tkDMCNPron3F3p3iW?usp=sharing)

## Clustering with Python

[![Clustering with Python](https://i.ytimg.com/vi_webp/lcMWH67TiWE/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

*   **Main Topic:** Clustering (specifically, analysis of clustered data, likely in a financial context)
*   **Headings:**
    *   cluster
    *   size
    *   Price
    *   Market Cap
    *   Free Float Market Cap
    *   % ADV
    *   RoE %
    *   ROCE %
    *   EBIT Margin %
    *   EPS
    *   PAT %
    *   Stock Return %
*   **Formulas/Concepts (implied):**  The headings indicate a focus on financial ratios and market capitalization metrics, implying the use of these concepts for clustering financial entities (likely stocks).  "Free Float" and "ADV" (Average Daily Volume) are typical finance terms.
*   **Notebook:** The image appears to be a screenshot of a Jupyter Notebook (likely Google Colab), which is a common tool for data analysis and machine learning. This suggests that the clustering analysis was performed programmatically.
](https://youtu.be/lcMWH67TiWE)

- [Jupyter Notebook](https://colab.research.google.com/drive/14-k1Pe0JgyLDsmzLeKPaWGCcQZktvMbg?usp=sharing)
- [How does K-Means clustering work?](https://youtu.be/4b5d3muPQmA)

## Sentiment analysis with Python and SpaCy

[![Sentiment analysis with Python and SpaCy](https://i.ytimg.com/vi_webp/A9WX7HaS1eU/sddefault.webp)

> 📘 **Image Description:** Here's a description of the study-related content in the image:

**Main Topic:** Sentiment Analysis/Text Classification

**File Name:** ImdbTextClassification.ipynb (Indicates it's likely a sentiment analysis project using IMDB movie reviews)

**Code Sections & Operations:**

*   **Data Preparation:**
    *   Lines 2, 3, and 4 show sample movie review texts along with their pre-determined sentiments (positive, negative, positive). This indicates the existence of labeled data for training or evaluation.

*   **Feature Extraction using TextBlob:**
    *   `data['TextBlob_Subjectivity'] = data['review'].apply(lambda x: TextBlob(x).sentiment.subjectivity)`
        This line calculates the subjectivity score for each review using the TextBlob library. The `apply()` function applies the lambda function to each 'review' in the 'data' DataFrame. The lambda function creates a TextBlob object from the review text and extracts its subjectivity.
    *   `data['TextBlob_Polarity'] = data['review'].apply(lambda x: TextBlob(x).sentiment.polarity)`
        Similar to subjectivity, this calculates the polarity score (positive or negative) for each review using TextBlob.

*   **Sentiment Analysis Based on Polarity:**
    *   `data['TextBlob_Analysis'] = data['TextBlob_Polarity'].apply(lambda x: 'negative' if x < 0 else 'positive')`
        This line creates a sentiment classification based on the polarity score. If the polarity is less than 0, it's classified as 'negative'; otherwise, it's classified as 'positive'.

*   **Evaluation:**
    *   `print(classification_report(data['sentiment'], data['TextBlob_Analysis']))`
        This suggests the use of a classification report from scikit-learn (or a similar library) to evaluate the performance of the sentiment analysis. It compares the pre-existing 'sentiment' labels (the ground truth) with the sentiment predictions made by the 'TextBlob_Analysis' column.

**Overall:**

The code snippet demonstrates a simple sentiment analysis pipeline:

1.  Load/prepare labeled text data (IMDB reviews).
2.  Extract sentiment features (subjectivity and polarity) using TextBlob.
3.  Classify sentiment based on polarity scores.
4.  Evaluate the classification performance using a classification report.
](https://youtu.be/A9WX7HaS1eU)

- [Jupyter Notebook](https://colab.research.google.com/drive/12SfxjYim6uijklYiByZCZDagTwPCF-MD?usp=sharing)
- Learn about the [pandas module](https://pandas.pydata.org/pandas-docs/stable/user_guide/10min.html) and [video](https://youtu.be/vmEHCJofslg)
- Learn about the [TextBlob module](https://textblob.readthedocs.io/en/dev/) and [video](https://youtu.be/qTyj2R-wcks)

## Sentiment analysis with Excel and Azure ML

[![Sentiment analysis with Excel and Azure ML](https://i.ytimg.com/vi_webp/wkbYLFEBCJg/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

**Main Topic:** Sentiment Analysis

**Data:** The data is organized in an Excel spreadsheet.

**Columns:**

*   **Tweet\_tex:** This column likely contains the text of a tweet.
*   **actual\_lat:** This seems to show the actual labeling of a given sentiment as negative or positive.
*   **Sentiment:** This column likely represents the result of sentiment analysis of a given tweet, classifying it as "positive" or "negative."
*   **Score:** This column likely displays a numerical score that reflects the confidence or intensity of the sentiment analysis result.
*   **Row Labels:** Columns with "negative", "positive" and "Grand Total" indicating a count of each.
*   **Count of Sentiment:** Column displaying the number of tweets for each Row Label.
*   **Percentage:** Column representing the percentage of each Row Label.
*   **Count of actual\_label**: Column displaying the number of tweets for each Row Label.
*   **Column Labels**: Columns with "positive" and "Grand Total" indicating a count of each.

**Formulas (likely present in the background, not explicitly visible):**

*   **Percentage Calculation:** The "Percentage" column would likely involve a formula to calculate the percentage of each sentiment (positive/negative) from the total number of tweets.
*   **Counting (COUNTIF or similar):** Formulas like `COUNTIF` are probably used to count the number of tweets classified as "positive" or "negative" based on the sentiment analysis.

**Overall:**

The image shows a study related to sentiment analysis, comparing what the actual sentiment label is, and the score that has been given by the sentiment analysis. The data is being organized and summarized in an Excel spreadsheet. This might be for evaluation of a sentiment analysis model. The popup menu on sentiment labels shows it is using filters to only show negative or positive tweets to analyse further.
](https://youtu.be/wkbYLFEBCJg)

- [Excel Sentiment Analysis Workbook](https://docs.google.com/spreadsheets/d/1ZwGixdzUClEF9L1_Ec4t9zB8Ls3-zZdu/edit#gid=1600996918)
- [Excel Azure ML](https://appsource.microsoft.com/en-us/product/office/wa104379638?tab=overview)

## Image auto classification with Google Cloud Vision

[![Image auto classification with Google Cloud Vision](https://i.ytimg.com/vi_webp/z4MUpn4FRTw/sddefault.webp)

> 📘 **Image Description:** Certainly! Here's a description of the study-related content in the image:

**Main Topic:** Image Classification/Machine Learning on Google Cloud Platform

**Content:**

*   **Interface:** The image shows the interface of Google Cloud Platform's Vision tool, likely used for image classification.
*   **Headings:**
    *   "Vision" (Likely the name of the service)
    *   "Import," "Images," "Train," "Evaluate," "Test & Use" (These represent the stages of a typical machine learning workflow.)
    *   "Datasets," "Models" (Categories for organizing the project data)
    *   "Filter" "Filter images"
    *   "LABEL STATS"
    *   "EXPORT DATA"
*   **Labels:**
    *   Bishop
    *   King
    *   Knight
    *   Pawn
    *   Queen
    *   Rook

*   **Data:**
    *   "All images 550"
    *   "Labeled 550"
    *   "Unlabeled 0"
    *   The numbers next to the labels ("Bishop 87", "King 75", etc.) indicate the number of images belonging to each class.
*   **Images:** There are thumbnails of chess pieces displayed, classified as "Rook," "Bishop."
](https://youtu.be/z4MUpn4FRTw)

- [Chessman image dataset](https://www.kaggle.com/datasets/niteshfre/chessman-image-dataset)
- [Google Cloud AutoML](https://cloud.google.com/automl/)

## Image classification with Python (Keras)

[![Image classification with Python](https://i.ytimg.com/vi_webp/59u3XMiSyro/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

*   **Main Topic:** Image classification of Chess Pieces. This is evident from the file name "kaggle\_chess\_classification.ipynb" and the directory structure "Chessman-image-dataset" which contains subfolders for each chess piece type (Bishop, King, Knight, Pawn, Queen, Rook).

*   **Data Structure:**  The file explorer shows a directory structure for the chess pieces, indicating training data is likely organized by the type of piece.

*   **Code:** The code snippet shows the class name extraction and processing.
    *   `class_names = train.class_names`
    *   `labels = np.array([])`
    *   `for _, label in train:`
    *   `labels = np.concatenate((labels, np.argmax(label, axis=-1)))`

*   **Formulas & Functions:**
    *   `np.array([])`:  Creates an empty NumPy array.
    *   `np.concatenate()`:  Concatenates arrays.
    *   `np.argmax(label, axis=-1)`:  Finds the indices of the maximum values along an axis of an array. In this case, it likely identifies the class with the highest probability for each image.

**In summary:** The image represents a study related to classifying images of chess pieces, likely using a machine learning model. The code focuses on preparing labels for the training data.
](https://youtu.be/59u3XMiSyro)

- [Jupyter Notebook](https://colab.research.google.com/drive/1aU3eFkwRO-Ldu_QwmJ_JduRW7TOUVDlQ?usp=sharing)
- [Chessman image dataset](https://www.kaggle.com/datasets/niteshfre/chessman-image-dataset)
- Learn about the [keras module](https://keras.io) and [video](https://youtu.be/qFJeN9V1ZsI)
- Learn about the [pandas module](https://youtu.be/vmEHCJofslg) and [video](https://youtu.be/vmEHCJofslg)
- Learn about the [seaborn module](https://seaborn.pydata.org/tutorial.html) and [video](https://www.youtube.com/playlist?list=PL998lXKj66MpNd0_XkEXwzTGPxY2jYM2d)
- Learn about the [matplotlib module](https://matplotlib.org/stable/users/explain/quick_start.html) and [video](https://youtu.be/3Xc3CA655Y4)
- Learn about [sklearn.metrics.classification_report](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.classification_report.html) and [video](https://youtu.be/LEPyAspkkew)

## Narratives with Quill on Tableau

-[![Narratives with Quill on Tableau](https://i.ytimg.com/vi/b_Qojb9gLzA/sddefault.jpg)

> 📘 **Image Description:** Here's a breakdown of the study-related content visible in the image:

**Main Topic:** The image displays a bar chart visualization, likely created in Tableau, showing the relationship between "Location" (countries) and their "Stringency Index." The Stringency Index seems to be a measure, possibly related to the strictness of policies (likely COVID-19 related based on common applications of this metric) imposed in different countries.

**Headings/Labels:**

*   **Columns:** "Location" - refers to the countries/regions displayed on the x-axis.
*   **Rows:** "SUM(Stringency Index)" - Shows the summed Stringency index and represents the values on the y-axis.

**Formulas/Calculations (Inferred):**

*   `SUM(Stringency Index)`: This indicates that the Stringency Index values for each location have been summed up. This could be a summation over a specific period.

**Data Fields Visible:**

The left panel (Data pane in Tableau) lists available data fields, some of which are:

*   Date
*   Iso Code
*   Location
*   Month
*   Week
*   Year
*   Measure Names
*   Aged 65 Older
*   Aged 70 Older
*   Cardiovascular Death Rate
*   Diabetes Prevalence
*   GDP per Capita
*   Hospital Beds Per Thousand
*   Human Development Index
*   Life Expectancy
*   Median Age
*   New Cases
*   New Cases per Million
*   New Deaths
*   New Deaths per Million
*   Population
*   Population Density
*   Stringency Index

**Overall Interpretation:**

The image shows someone using Tableau to visualize and analyze data related to various countries, potentially focusing on how the stringency of government policies varies across locations. The presence of other fields like "New Cases," "New Deaths," and population-related measures suggests an analysis of the impact of policies on COVID-19 outcomes.
](https://youtu.be/b_Qojb9gLzA)

## Comic narratives with Google Sheets & Comicgen

[![Comic narratives with Google Sheets & Comicgen](https://i.ytimg.com/vi/HZDqCQBpHGI/sddefault.jpg)

> 📘 **Image Description:** Based on the image, the study-related content is centered around "data storytelling" and the use of comics.  Here's a breakdown:

*   **Main Topic:** Data Storytelling, potentially using comics.
*   **Headings/Phrases:**
    *   "Interested in data storytelling?"
    *   "#ComicgenFriday community"
    *   "Data Comicgen Awards"
    *   "Discuss on Twitter: #comicgen"
*   **Formulas/Equations:** There are no mathematical formulas visible in the image. However, there's a long URL that defines parameters for generating a comic, suggesting underlying programming or scripting related to data visualization.

In essence, the content promotes the idea of using comics to effectively communicate data insights.
](https://youtu.be/HZDqCQBpHGI)

- [Sample sheet](https://docs.google.com/spreadsheets/d/1b0DOfJnnx6MFcN955YqRqYafLb8XrH-zqtLaK2h5kkc/edit#gid=1534638946)

## Optional: Scaling hotstar.com for 25 million concurrent viewers

[![Optional : Scaling hotstar.com](https://i.ytimg.com/vi/QjvyiyH4rr0/sddefault.jpg)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

*   **Main Topic:** Scaling the Hotstar platform to handle 25 million concurrent viewers. This implies a discussion of system architecture, infrastructure, and optimization techniques.

*   **Headings:**
    *   "hotstar tech_" - This likely indicates a presentation or talk related to the technology used at Hotstar.
    *   "Scaling hotstar for 25 million concurrent viewers" - This is the main title of the presentation.

*   **Other Information:**
    *   Gaurav Kamboj, Cloud Architect at Hotstar: This gives the presenter's name and role, indicating expertise in cloud infrastructure and scalability.
    *   @oyehooye: This is a Twitter handle.

*   **Formulas:**
    *   There are no explicit formulas visible in the provided image. However, a presentation on scaling a platform could potentially involve formulas related to load balancing, resource utilization, or network bandwidth.
](https://youtu.be/QjvyiyH4rr0)

## Supplementary material

- [Using Inspect element to find APIs](https://youtu.be/_gpBxglbDY4)
- Learn about the [urllib.parse package](https://docs.python.org/3/library/urllib.parse.html). [Video](https://youtu.be/LosIGgon_KM)
- Learn about the [os package](https://docs.python.org/3/library/os.html) and [video](https://youtu.be/tJxcKyFMTGo)

# Deployment

[![Deployment](https://i.ytimg.com/vi_webp/YSGZjCxhIkk/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

*   **Main Topic:** Deploying the results of a data science project.
*   **High-Level Steps:**
    *   Anonymize Data
    *   Build App
    *   Host App

*   **Content details:**
    *   **Anonymize Data:**
        *   Tools: ARX, Amnesia
        *   Libraries: Faker, Mimesis
    *   **Build App:**
        *   Notebook (Colab, Kaggle)
        *   Data App (Streamlit, Shiny)
        *   Web App (Flask, Tornado)
    *   **Host App** This step is only titled, but does not contain further content.
](https://youtu.be/YSGZjCxhIkk)

## Tools to anonymize data

[![Tools to anonymize data](https://i.ytimg.com/vi_webp/N8I-sxmMfqQ/sddefault.webp)

> 📘 **Image Description:** Sorry, but I'm unable to make out any study-related content in the image you sent. It simply shows a gray rectangle with three circles inside, somewhat similar to a loading symbol or a placeholder image.
](https://youtu.be/N8I-sxmMfqQ)

- [List of Tools](https://aircloak.com/top-5-free-data-anonymization-tools/)

## Libraries to build web applications

[![Libraries to build web applications](https://i.ytimg.com/vi_webp/iT5sS1dWMcc/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content from the image:

*   **Main Topic:** Credit Card Default Prediction

*   **Heading:** Credit Card Default Prediction App

*   **Description:** "This app predicts the credit card Default probability"

*   **Section Heading:** User Input Parameters

*   **Input Parameters:**
    *   CODE\_GENDER
    *   FLAG\_OWN\_CAR
    *   FLAG\_OWN\_REALTY
    *   FLAG\_WORK\_PHONE
    *   FLAG\_EMAIL
    *   FLAG\_PHONE
](https://youtu.be/iT5sS1dWMcc)

- [List of frameworks](https://www.datarevenue.com/en-blog/data-dashboarding-streamlit-vs-dash-vs-shiny-vs-voila)
- [Code - Streamlit](https://github.com/rohithsrinivaas/streamlit-heroku)
- [Notebook - Streamlit](https://colab.research.google.com/drive/1Qd2xRdyd6SA8xaimUmlBDyu2FYnTpUar?usp=sharing)

## Services to host web applications

[![Services to host web applications](https://i.ytimg.com/vi_webp/V5dl7zkKXC0/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

**Main Topic:** Deployment Pipelines using Heroku and GitHub.

**Headings:**

*   Add this app to a pipeline
*   Add this app to a stage in a pipeline to enable additional features
*   Deployment method
*   App connected to GitHub
*   Automatic deploys

**Key Concepts and Keywords:**

*   Pipeline
*   Stage
*   GitHub
*   Heroku
*   Container Registry
*   Automatic deploys
*   Branch
*   Code diffs
*   Pull requests
*   Review apps

**Formulas/Code:** There are no apparent formulas, but there are references to changing branches and pushing code.

**In Summary:** The image appears to show a Heroku interface for setting up a deployment pipeline that connects to a GitHub repository. The user is configuring how changes to the code in the repository are automatically deployed to their Heroku app. It is a tutorial or a guide on how to set up an automatic deployment pipeline using Heroku and GitHub.
](https://youtu.be/V5dl7zkKXC0)

- [List and comparison](https://sourceforge.net/software/compare/Glitch-vs-Heroku-vs-Netlify-vs-Vercel/)
- [Heroku deployment](https://www.heroku.com/home)
- Docker/Podman
- GitHub actions
- Glitch.me

# Data Discovery

[![Data discovery](https://i.ytimg.com/vi_webp/3OeMOb7gByE/sddefault.webp)

> 📘 **Image Description:** Here is the description of the study-related content in the image:

*   **Main Topic:** Data Science
*   **Headings:** "Discover the Data," "Tools in Data Science"
*   **Visual Elements:**  Various types of data visualizations such as bar charts, pie charts, line graphs, diagrams of ideas, and indicators of progress (e.g., 100%).

The image suggests a presentation or lecture focused on tools used in the data science field to explore and understand data.
](https://youtu.be/3OeMOb7gByE)

Before we begin the data science journey, you first need the data set. And to get the
data set, you need to know where it is. This is what we will be covering in the first module.

How do you discover data? There are three things that you will learn in this module.

- The first is, what are the different sources of data sets? Where can you find them?
- The second is, what are the different kinds of data sets? Structured, unstructured and semi-structured.
- Third, in each data set, what are the different kinds of values that you will find?

This will give you a sense of locating the kind of data set that you want, either on the internet
or within your organization or even within your phones.

## Sources of Data

[![Sources of Data](https://i.ytimg.com/vi_webp/GY5l_5RpVZM/sddefault.webp)

> 📘 **Image Description:** Here is the description of the study-related content in the image:

*   **Main Topic:** Sources of Datasets

*   **Headings:**
    *   Sources of Datasets
    *   Public Data
    *   Private Data
    *   Personal Data

*   **Content related to Public Data:**
    *   Awesome Public Datasets
    *   Google Dataset Search
    *   Kaggle
    *   Data.gov.*
](https://youtu.be/GY5l_5RpVZM)

- [Awesome public datasets](https://github.com/awesomedata/awesome-public-datasets)
- [Google dataset search](https://datasetsearch.research.google.com/)
- [Kaggle datasets](https://www.kaggle.com/datasets/)
- [Data.gov](https://data.gov/) and [Data.gov.in](https://data.gov.in/)
- [Datameet](https://datameet.org/)

## Types of datasets

[![Types of datasets](https://i.ytimg.com/vi_webp/u8PIxqsi1kk/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

*   **Main Topic:** The image appears to be about **Types of datasets**.
*   **Headings:** The image lists three types of datasets:
    *   Structured
    *   Semi-structured
    *   Unstructured
*   **Content Related to Headings:** Under the "Structured" heading, there is a text item that says "Databases."

There are no visible formulas in the image.
](https://youtu.be/u8PIxqsi1kk)

- Structured data has a schema: Databases, Spreadsheets, Forms, Shapefiles
- Semi-structured data has a flexible schema: JSON, HTML, Email
- Unstructured data has no schema: Text, Images, Audio, Video
- [DBF opener](https://www.dbfopener.com/)
- [MapShaper lets you view Shapefiles](https://mapshaper.org/)

## Types of values

[![Types of values](https://i.ytimg.com/vi_webp/HlsqT0r9wAM/sddefault.webp)

> 📘 **Image Description:** Here is a description of the study-related content in the image:

*   **Main Topic:** Types of Values
*   **Categories:**
    *   Categorical
        *   Boolean (True, False)
        *   Unordered (Red, Blue, Green)
        *   Ordered (Low, Medium, High)
    *   Numerical
    *   Composite
](https://youtu.be/HlsqT0r9wAM)

- Categorical values may be:
  - Boolean: True or False
  - Unordered: No order, like colors
  - Ordered: Order, like ratings
  - Cyclical: Like days of the week
  - Unstructured: Like names, images
- Numerical values may be:
  - Integer: You can add or subtract
  - Real: You can multiply or divide
- Composite values have an internal structure
  - Temporal: Date, Time
  - Spatial: Latitude, Longitude, Shapefiles
  - Structured: JSON, XML with schema
  - Specialized: IP addresses, URLs, Email addresses, Phone numbers, etc.

## Week Summary

[![Discover the Data - Summary](https://i.ytimg.com/vi_webp/NNiFxgANu8Y/sddefault.webp)

> 📘 **Image Description:** Certainly! Let's break down the study-related content in the image.

**Main Topic:**

The main topic is **Data Science**.

**Headings/Titles:**

*   **"Discover the Data"** (This appears to be the primary title of the presentation or module.)
*   **"Tools in Data Science"** (This is a subtitle, likely indicating the specific aspect of data science being covered.)

**Visual Elements:**

The background contains visual elements commonly associated with data analysis and visualization:

*   **Graphs and Charts:** Bar graphs, pie charts, line graphs, scatter plots are the illustrations.
*   **Arrows:**  Representing flow or connections.
*   **Lightbulbs with "IDEA":**  Illustrating the concept of insight generation and problem-solving.
*   **Checkmarks**
*   **Percentage Symbols**

**Overall:**

The image introduces a study-related topic focusing on discovering data within the field of data science, and it suggests an exploration of the tools used in the process. The visual elements emphasize data analysis, idea generation, and presentation of insights.
](https://youtu.be/NNiFxgANu8Y)

Based on what you have learnt in this module, you should be able to do two things: find data and understand what type of data it is.

Both of these are powerful skills.

The more data you are able to find, the more analysis that you will be able to do that others are unable to.
Therefore, discovering new sources of data is a competitive advantage and a skill that is well worth building.

The other, in terms of understanding the type of data, will give you an edge in terms of knowing which data set is easier to work with.
Structured data is easier to work with because you don't have to do any additional work.
You don't have to extract information from it.
Numerical values are easier to work with than, let's say, categorical or composite because there's less effot to extract the structure.
So you'll be able to compare two data sets and say that one gets more results by spending in less time and effort.

## Sample questions

- Find the UCI machine learning dataset on Wine Quality. (It has 4,898 rows.) What is the highest pH value of the red wines? (ANS: 4.01)
- What's the official data portal of Russia? (ANS: <https://data.gov.ru/?language=en>)
- Are research papers structured, semi-structured or unstructured? (ANS: Semi-structured. They have author names, abstracts, keywords, etc. but most content is free-form.)
- Are book titles categorical or composite? (ANS: Categorical. They don't have an underlying structure.)

## Optional: Tools used in the industry

Kathir Mani from QueLit and Anand S from Gramener discuss the tools and technologies used in the industry. (9 min)

[![Podcast (9 min)](https://i.ytimg.com/vi_webp/DH0Q4LiSgkE/sddefault.webp)

> 📘 **Image Description:** Unfortunately, I am unable to determine any study-related content from the image.
](https://youtu.be/DH0Q4LiSgkE)

## Scraping: Reference and helpful content

- For those who don't know HTML, CSS, or JavaScript, this [FreeCodeCamp Responsive Web Design course](https://www.freecodecamp.org/learn/2022/responsive-web-design) is a good starting point.
- For those who don't know Python, this [Learn Python video](https://youtu.be/rfscVS0vtbw) and this [Python for Beginners](https://youtube.com/playlist?list=PLsyeobzWxl7poL9JTVyndKe62ieoN-MZ3&feature=shared) playlist is a good starting point.
- Few More Scraping tools
  1. [About Scrapy & Chrome Web Scraper Extension](https://docs.google.com/document/d/1QZPJIfg98-Gox7_tqzrqPy9PigYfRfgpsYgTHcBAYFM/view) [(Video)](https://youtu.be/s4jtkzHhLzY)
  2. Chrome Web Scraper Extension [(Video)](https://youtu.be/aClnnoQK9G0)

## Scraping: Sample questions

- Read the [Hacker News API docs](https://github.com/HackerNews/API). Now, when was the post with ID `2921983` posted? Specifically, What is the timestamp? (ANS: 1314211127)
- Using [PokeAPI](https://pokeapi.co/), in the `sun-moon` version, find out how many moves `ivysaur` has that `bulbasaur` does not. (ANS: 1: leech-seed).
- How many images (`<img>` tags) does this [White House page snapshot](https://web.archive.org/web/20110101070603id_/https://www.whitehouse.gov/) have inside a link (`<a>` element)? (ANS: 15)
- What is the westernmost point (highest longitude) on the bounding box of `Baghdad, Iraq`, according to the Nominatim API? If there are multiple matches, get the highest longitude across all bounding boxes. (ANS: 44.969°E)
- What CSS selector would you use to extract the last list element with a class `highlight` from an unordered list? (ANS: `ul li.highlight:last-child`)

## Smart Narratives with Power BI

[![Smart narratives with Power BI](https://i.ytimg.com/vi_webp/eHmvCNhZiWg/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content visible in the image:

*   **Software:** The image shows the Power BI Desktop application.
*   **Main Topic:** Population Estimates by City.
*   **Chart:** A bar chart visualizing the "UN 2018 population estimates[s]" (y-axis) for various cities (x-axis).
*   **Fields Used:**
    *   City[s]
    *   UN 2018 population estimate[s]
*   **Filters:** There is a section with filters for cities, including a search bar.
*   **Other Relevant Fields:** The "Fields" panel shows other available fields that are potentially related to the population data, such as: "City props[s] to area," "Metropolitan area[s]", "New City props[s]", "Country", and "Urban area[s]".
](https://youtu.be/eHmvCNhZiWg)

## Apache Airflow

1. [Overview of Apache Airflow](https://airflow.apache.org/docs/apache-airflow/stable/)
2. [Airflow Playlist](https://www.youtube.com/playlist?list=PL5_c35Deekdm6N1OBHdQm7JZECTdm7zl-)
