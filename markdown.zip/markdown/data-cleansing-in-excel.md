## Data Cleansing in Excel

[![Clean up data in Excel](https://i.ytimg.com/vi_webp/7du7xkqeu4s/sddefault.webp)

> 📘 **Image Description:** Here's a description of the study-related content in the image:

**Main Topic:** The spreadsheet appears to be about city populations, areas, and densities.

**Headings (Columns):**

*   **A:** City(a)
*   **B:** Country
*   **C:** UN 2018 population estimates[b]
*   **D:** City proper(c) Definition
*   **E:** City proper(c) Population
*   **F:** City proper(c) Area (km2)
*   **G:** City proper(c) Density (/km2)

**Content Examples:**

*   The data includes cities like Tokyo, Delhi, Seoul, Shanghai, Sao Paulo, Mexico City, Cairo, Mumbai, and Beijing.
*   It lists the country each city is in.
*   It provides the UN estimated population for 2018.
*   It defines what the city is (e.g., Metropolis prefecture, Capital City, Municipality).
*   It shows the city's proper population, area in square kilometers, and density (people per square kilometer).

**Possible Formulas/Calculations:** While not explicitly shown, column G "City proper(c) Density (/km2)" is most likely calculated using the formula:

    Density = Population / Area

    (Column E / Column F)
](https://youtu.be/7du7xkqeu4s)

You'll learn basic but essential data cleaning techniques in Excel, covering:

- **Find and Replace**: Use Ctrl+H to replace or remove specific terms (e.g., removing "[more]" from country names).
- **Changing Data Formats**: Convert columns from general to numerical format.
- **Removing Extra Spaces**: Use the TRIM function to clean up unnecessary spaces in text.
- **Identifying and Removing Blank Cells**: Highlight and delete entire rows with blank cells using the "Go To Special" function.
- **Removing Duplicates**: Use the "Remove Duplicates" feature to eliminate duplicate entries, demonstrated with country names.

Here are links used in the video:

- [List of Largest Cities Excel file](https://docs.google.com/spreadsheets/d/1jl8tHGoxmIba4J78aJVfT9jtZv7lfCbV/view)
