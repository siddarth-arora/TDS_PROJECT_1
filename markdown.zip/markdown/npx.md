## JavaScript tools: npx

[npx](https://docs.npmjs.com/cli/v8/commands/npx) is a command-line tool that comes with npm (Node Package Manager) and allows you to execute npm package binaries and run one-off commands without installing them globally. It's essential for modern JavaScript development and data science workflows.

For data scientists, npx is useful when:

- Running JavaScript-based data visualization tools
- Converting notebooks and documents
- Testing and formatting code
- Running development servers

Here are common npx commands:

```bash
# Run a package without installing
npx http-server .                # Start a local web server
npx prettier --write .           # Format code or docs
npx eslint .                     # Lint JavaScript
npx typescript-node script.ts    # Run TypeScript directly
npx esbuild app.js               # Bundle JavaScript
npx jsdoc .                      # Generate JavaScript docs

# Run specific versions
npx prettier@3.2 --write .        # Use prettier 3.2

# Execute remote scripts (use with caution!)
npx github:user/repo            # Run from GitHub
```

Watch this introduction to npx (6 min):

[![What you can do with npx (6 min)](https://i.ytimg.com/vi_webp/55WaAoZV_tQ/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content I can identify in the image:

*   **Main Topic:** The image displays the phrase "what you can do with npx". This suggests the image is related to the npx command line tool.
*   **Headings:** The phrase "what you can do with" serves as a heading, introducing the purpose or scope of the content.
*   **Formulas:** There are no explicit mathematical formulas in the image.
*   **Keywords:** npx

Based on this, I can infer that the image is likely an introductory slide or title screen for a presentation, tutorial, or guide discussing npx and its potential applications.
](https://youtu.be/55WaAoZV_tQ)
