## Forecasting with Excel

[![Forecasting with Excel](https://i.ytimg.com/vi_webp/QrTimmxwZw4/sddefault.webp)

> 📘 **Image Description:** The image shows an Excel spreadsheet and a chart.

*   **Main topic:** The chart's title is "Vehicles," suggesting that the spreadsheet contains data related to vehicle counts or traffic.
*   **Data:** The spreadsheet columns are as follows:
    *   Column A: Dates and Times. The dates are all "31-12-2015," with times ranging from 02:00 to 23:00, in one-hour intervals.
    *   Column B: Numerical data related to the "Vehicles."
*   **Chart:** The chart appears to be a time-series plot, with time on the horizontal axis and "Vehicles" (count) on the vertical axis. It looks like a line chart with the line being blue. The x-axis has evenly spaced numbers beginning at 1 and ending with 1444, while the y-axis goes from 0 to 60 in increments of 10.
](https://youtu.be/QrTimmxwZw4)

Here are links used in the video:

- [FORECAST reference](https://support.microsoft.com/en-us/office/forecast-and-forecast-linear-functions-50ca49c9-7b40-4892-94e4-7ad38bbeda99)
- [FORECAST.ETS reference](https://support.microsoft.com/en-us/office/forecast-ets-function-15389b8b-677e-4fbd-bd95-21d464333f41)
- [Height-weight dataset](https://docs.google.com/spreadsheets/d/1iMFVPh8q9KgnfLwBeBMmX1GaFabP02FK/view) from [Kaggle](https://www.kaggle.com/datasets/burnoutminer/heights-and-weights-dataset)
- [Traffic dataset](https://docs.google.com/spreadsheets/d/1w2R0fHdLG5ZGW-papaK7wzWq_-WDArKC/view) from [Kaggle](https://www.kaggle.com/datasets/fedesoriano/traffic-prediction-dataset)
