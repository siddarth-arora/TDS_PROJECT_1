## LLM Sentiment Analysis

[OpenAI's API](https://platform.openai.com/) provides access to language models like GPT 4o, GPT 4o mini, etc.

For more details, read OpenAI's guide for:

- [Text Generation](https://platform.openai.com/docs/guides/text-generation)
- [Vision](https://platform.openai.com/docs/guides/vision)
- [Structured Outputs](https://platform.openai.com/docs/guides/structured-outputs)

Start with this quick tutorial:

[![OpenAI API Quickstart: Send your First API Request](https://i.ytimg.com/vi_webp/Xz4ORA0cOwQ/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

**Main Topic:**  The image shows a `.zshrc` file, which is a configuration file for the Zsh shell (a type of command-line interpreter). It's being used to configure environment variables and settings.

**Headings (indicated by `#` at the start of the line):**

*   `# OpenAI`
*   `# Load Angular CLI autocompletion.`

**Environment Variable Declarations (formulas):**

*   `export PATH="/opt/homebrew/opt/ruby/bin:$PATH"`
*   `export LANG=en_US.UTF-8`
*   `export LANGUAGE=en_US.UTF-8`
*   `export LC_ALL=en_US.UTF-8`
*   `export ANDROID_HOME=$HOME/Library/Android/sdk`
*   `export PATH=$PATH:$ANDROID_HOME/emulator`
*   `export PATH=$PATH:$ANDROID_HOME/platform-tools`
*   `export PATH=/usr/local/bin:$PATH`
*   `export PATH="$PATH:/Users/amosgyamfi/.local/bin"`
*   `export OPENAI_API_KEY='sk-proj-qZIGbilFyPY'`

**Other Commands:**

*   `source <(ng completion script)`
*   `eval "$(~/.local/bin/mise activate zsh)"`

**Explanation:**

*   **Environment Variables:** The `export` commands set environment variables.  These variables store information that the operating system and applications can use.  Examples include `PATH` (where to find executable programs), language settings (`LANG`, `LANGUAGE`, `LC_ALL`),  Android SDK paths (`ANDROID_HOME`), and API keys (e.g., `OPENAI_API_KEY`). The `PATH` settings are critical for the command line shell to find the correct executables.
*   **Zsh Configuration:**  The `.zshrc` file is read every time a new Zsh shell is started. This ensures that these environment variables and other settings are available in each new terminal session.
*   **Angular CLI Autocompletion:**  The `source` command is used to run the `ng completion script`. This will allow tab completion for Angular CLI commands in the terminal
*   **Mise Activation:** The `eval` command allows Zsh to execute the output of a given command, in this case, the command activates the "mise" environment (likely for managing specific programming language versions or dependencies)

In summary, the content is a set of shell commands for configuring a development environment, including setting the `PATH`, language settings, Android SDK paths, API keys, and enabling autocompletion for specific tools.
](https://youtu.be/Xz4ORA0cOwQ)

Here's a minimal example using `curl` to generate text:

```bash
curl https://api.openai.com/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -d '{
    "model": "gpt-4o-mini",
    "messages": [{ "role": "user", "content": "Write a haiku about programming." }]
  }'
```

Let's break down the request:

- `curl https://api.openai.com/v1/chat/completions`: The API endpoint for text generation.
- `-H "Content-Type: application/json"`: The content type of the request.
- `-H "Authorization: Bearer $OPENAI_API_KEY"`: The API key for authentication.
- `-d`: The request body.
  - `"model": "gpt-4o-mini"`: The model to use for text generation.
  - `"messages":`: The messages to send to the model.
    - `"role": "user"`: The role of the message.
    - `"content": "Write a haiku about programming."`: The content of the message.

[![LLM Sentiment Analysis](https://i.ytimg.com/vi_webp/_D46QrX-2iU/sddefault.webp)

> 📘 **Image Description:** Based on the image and the OCR, the study-related content seems to be a review or analysis of the TV show "OZ." 

Here's a breakdown:

*   **Main Topic:** The TV series "OZ" (about a fictional prison)
*   **Key phrases:**
    *   "It is called OZ as that is the nickname for Security State Penitentiary"
    *   "experimental section of the prison"
    *   "fronts and face inwards, so privacy is"
    *   "Aryans, Muslims, gangsters, Italians, Irish and more"
    *   "scuffles and shady agreements are never far away"
    *   "main appeal of the show is due to the fa"

The text appears to describe the setting, characters, and themes of the show.

There are no formulas or traditional headings visible. The format looks like notes, potentially taken in a code editor (like VS Code) based on the dark theme.
](https://youtu.be/_D46QrX-2iU)

This video explains how to use large language models (LLMs) for sentiment analysis and classification, covering:

- **Sentiment Analysis**: Use OpenAI API to identify the sentiment of movie reviews as positive or negative.
- **Prompt Engineering**: Learn how to craft effective prompts to get desired results from LLMs.
- **LLM Training**: Understand how to train LLMs by providing examples and feedback.
- **OpenAI API Integration**: Integrate OpenAI API into Python code to perform sentiment analysis.
- **Tokenization**: Learn about tokenization and its impact on LLM input and cost.
- **Zero-Shot, One-Shot, and Multi-Shot Learning**: Understand different approaches to using LLMs for learning.

Here are the links used in the video:

- [Jupyter Notebook](https://colab.research.google.com/drive/1tVZBD9PKto1kPmVJFNUt0tdzT5EmLLWs)
- [Movie reviews dataset](https://drive.google.com/file/d/1X33ao8_PE17c3htkQ-1p2dmW2xKmOq8Q/view)
- [OpenAI Playground](https://platform.openai.com/playground/chat)
- [OpenAI Pricing](https://openai.com/api/pricing/)
- [OpenAI Tokenizer](https://platform.openai.com/tokenizer)
- [OpenAI API Reference](https://platform.openai.com/docs/api-reference/)
- [OpenAI Docs](https://platform.openai.com/docs/overview)
