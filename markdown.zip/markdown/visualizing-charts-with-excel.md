## Visualizing Charts with Excel

[![Visualizing charts with Google Data StudioTools to visualize numbers](https://i.ytimg.com/vi_webp/sORnCj52COw/sddefault.webp)

> 📘 **Image Description:** Based on the image, the study-related content is centered around the "Datahack Summit 2017". It appears to be a summit or conference related to data science or related fields.  There are no visible headings, formulas, or equations in this image. The main topic is data science or data hacking, as indicated by the event's name.
](https://youtu.be/sORnCj52COw?t=1813s)
