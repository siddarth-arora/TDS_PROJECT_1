## Static hosting: GitHub Pages

[GitHub Pages](https://pages.github.com/) is a free hosting service that turns your GitHub repository directly into a static website whenever you push it. This is useful for sharing analysis results, data science portfolios, project documentation, and more.

Common Operations:

```bash
# Create a new GitHub repo
mkdir my-site
cd my-site
git init

# Add your static content
echo "<h1>My Site</h1>" > index.html

# Push to GitHub
git add .
git commit -m "feat(pages): initial commit"
git push origin main

# Enable GitHub Pages from the main branch on the repo settings page
```

Best Practices:

1. **Keep it small**
   - [Optimize images](https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Performance/Multimedia). Prefer SVG over WEBP over 8-bit PNG.
   - [Preload](https://developer.mozilla.org/en-US/docs/Web/HTML/Attributes/rel/preload) critical assets like stylesheets
   - Avoid committing large files like datasets, videos, etc. directly. Explore [Git LFS](https://git-lfs.github.com/) instead.

Tools:

- [GitHub Desktop](https://desktop.github.com/): GUI for Git operations
- [GitHub CLI](https://cli.github.com/): Command line interface
- [GitHub Actions](https://github.com/features/actions): Automation

[![Host a website using GitHub Pages](https://i.ytimg.com/vi_webp/WqOXxoGSpbs/sddefault.webp)

> 📘 **Image Description:** Here's a description of the study-related content within the image:

*   **Main Topic:** Hosting websites.
*   **Heading:** GitHub Pages. The text describes GitHub Pages as a service "designed to host your personal, organization..."
*   **Other elements**: There are labels referring to the "Source" and "Theme Chooser".
](https://youtube.com/shorts/WqOXxoGSpbs)

[![Deploy your first GitHub Pages Website](https://i.ytimg.com/vi_webp/sT_zXIX3ZA0/sddefault.webp)

> 📘 **Image Description:** Based on the image, here's a description of the study-related content:

**Main Topic:**

The main topic appears to be GitHub Actions, specifically an action designed to "Add collaborator."

**Headings and Structure:**

*   **GITHUB ACTIONS:** This is a primary heading, indicating the context of the content.
*   **CURRENT BRANCH**
*   **WORKFLOWS**
*   **InvitationLabel:** This seems to refer to the name of a specific workflow.
*   **#4400, #4392:** These appear to be identifiers for specific instances or versions of the "Add collaborator" action workflow.
*   **Add collaborator!**
*   **Set up job**
*   **Perform invitation action**
*   **Complete job**

**Formulas and Code Snippets:**

While there are no explicit mathematical formulas, the image contains code snippets related to GitHub Actions configuration. These include:

*   **SecurityEvents: write**
*   **Statuses: write**
*   **Secret source: Actions**
*   **Prepare workflow directory**
*   **Getting action download info**
*   **CLIENT_ID**, **APP_ID**, **CLIENT_SECRET**, **WEBHOOK\_SECRET**, **PRIVATE\_KEY**, **INSTALLATION\_ID**: These appear to be environment variables or secrets used by the action.
*   **ORG: false**
*   **Repo Owner: community**

**Content Summary:**

The image shows the configuration and execution logs of a GitHub Action designed to automatically add collaborators to a repository. It includes steps for setting up the job, performing the invitation action, and completing the process. The code snippets demonstrate the use of environment variables, secrets, and workflow configuration details. The text mentions "Parsed event values" and "Username of commenter: MridulS," suggesting that the action might be triggered by events related to user comments or interactions within the repository. The "Cleaning up orphan processes" at the end indicates a maintenance or cleanup step within the action.
](https://youtu.be/sT_zXIX3ZA0)
