# Data Storytelling

[![Narrate a story](https://i.ytimg.com/vi_webp/aF93i6zVVQg/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content from the image:

**Main Topic:** Channel Banking Performance Analysis

**Content Details:**

*   **Report Title:** Channel Banking Report for Sandra Miles, May 2016
*   **Sections:** The presentation is structured to focus on "Numbers," "Visuals," and "Text," likely indicating different methods of conveying the information.
*   **Key Performance Indicators (KPIs) and Data:**
    *   **Unique Mobile Banking Users:** A key focus is on the decline in unique users for mobile banking.
    *   *Initial Users:* 5.91 M
        *Decrease:* -0.9%
        *Final Users:* 5.86 Lk
    *   **Market Share:** The report mentions a 26.5% market share of active CASA clients using mobile banking.
    *   **Peer Ranking:** The company is ranked 2nd among 3 peers.
    *   **Target Achievement:**
        *Achieved:* 89.3% of the unique users target for the current month
        *Next Month Target:* 6.85 M
        *Current Number of Unique Users Achieved:* 62.5% of the 9.37 M target
    *   **Channel Performance:**
        *SMS Users:* Increased this month
        *LiteSite and App Users:* Decreased this month
        *SMS Growth*: 3.6%

In summary, the slide presents a summary of a channel banking report, highlighting concerns about declining unique mobile banking users and providing insights into channel-specific performance (SMS, LiteSite, and App). It also presents target achievement rates and a peer comparison.
](https://youtu.be/aF93i6zVVQg)
