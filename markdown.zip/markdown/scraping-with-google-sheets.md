## Scraping with Google Sheets

[![Scraping with Google Sheets](https://i.ytimg.com/vi_webp/eYQEk7XJM7s/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

**Main Topic:**

The content focuses on the `IMPORTHTML` function within a spreadsheet program (likely Google Sheets). This function is used to import data from tables or lists found on websites.

**Headings:**

*   **Sample Usage:** Shows examples of how to use the `IMPORTHTML` function.
*   **Syntax:**  Defines the structure and arguments of the `IMPORTHTML` function.

**Formulas:**

*   `IMPORTHTML("http://en.wikipedia.org/wiki/Demographics_of_India", "table", 4)`: This is an example of the function using a URL from Wikipedia, specifying that the desired data is in a "table," and indicating that it wants the 4th table on the page.
*   `IMPORTHTML(A2, B2, C2)`:  This is an example showing how to reference cell values as arguments within the `IMPORTHTML` function.

**Explanation of Syntax:**

*   `IMPORTHTML(url, query, index)`:
    *   `url`: The URL of the webpage to extract data from.
    *   `query`:  Specifies the type of data to extract. It can be either "list" or "table."
    *   `index`:  Indicates which table or list to retrieve, starting with 1.
](https://youtu.be/eYQEk7XJM7s)

You'll learn how to [import tables on the web using Google Sheets's `=IMPORTHTML()` formula](https://support.google.com/docs/answer/3093339?hl=en), covering:

- **Import HTML Formula**: Use =IMPORTHTML(URL, "query", index) to fetch tables or lists from a web page.
- **Granting Access**: Allow access for formulas to fetch data from external sources.
- **Checking Imported Data**: Verify if the imported table matches the data on the web page.
- **Handling Errors**: Understand common issues and how to resolve them.
- **Sorting Data**: Copy imported data as values and sort it within Google Sheets.
- **Freezing Rows**: Use frozen rows to maintain headers while sorting.
- **Live Formulas**: Learn how web data updates automatically when the source changes.
- **Other Import Functions**: IMPORTXML, IMPORTFEED, IMPORTRANGE, and IMPORTDATA for advanced data fetching options.

Here are links used in the video:

- [Google sheet used in the video](https://docs.google.com/spreadsheets/d/1Qp_YTh1-hJHxjMWE_GofkvLIKgEdKxb6NFImpId3z9o/view)
- [`IMPORTHTML()`](https://support.google.com/docs/answer/3093339)
- [`IMPORTXML()`](https://support.google.com/docs/answer/3093342)
- [Demographics of India](https://en.wikipedia.org/wiki/Demographics_of_India)
- [List of highest grossing Indian films](https://en.wikipedia.org/wiki/List_of_highest-grossing_Indian_films)
