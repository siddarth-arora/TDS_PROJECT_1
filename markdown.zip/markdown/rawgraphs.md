## RAWgraphs

[![RAWGraphs 1.0 - Introduction (1 min)](https://i.ytimg.com/vi_webp/2TtYlty-M5g/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

**Main Topic:** Data Visualization (specifically, different chart types)

**Headings:**

*   Choose a Chart
*   Scatter Plot
*   Convex Hull
*   Delaunay Triangulation
*   Hexagonal Binning
*   Voronoi Tessellation
*   Box plot
*   Circular Dendrogram
*   Cluster Dendrogram
*   Circle Packing
*   Clustered Force Layout
*   Sunburst
*   Treemap
*   Alluvial Diagram
*   Parallel Coordinates
*   Bar Chart
*   Pie Chart
*   Gantt Chart
*   Area Graph
*   Bump Chart
*   Horizon graph

**Formulas/Definitions (Implied/Brief):**

*   **Scatter Plot:** A scatter plot is a type of mathematical diagram using Cartesian coordinates to display values for two variables for a set of data.

**Additional Notes:**

*   The word "Dispersion" appears under several chart types, suggesting a category or characteristic they share.
*   The phrase "Hierarchy (weighted)" also appears under certain charts, indicating a visualization of hierarchical data with weightings.
*   The word "Multivariate" indicates the type of data visualized for Alluvial Diagram and Parallel Coordinates.
*   "Time series" indicates the type of data visualized for Gantt Chart, Area Graph, Bump Chart, and Horizon graph.
](https://youtu.be/2TtYlty-M5g)

- [RAWgraphs](https://www.rawgraphs.io/)
- [How to make Alluvial Diagram](https://youtu.be/6BYac2Pmnno)
- [How to make Sankey Diagram](https://youtu.be/DYTiKjH6oFM)
- [How to make Beeswarm Plot](https://youtu.be/RPHiEzbCatA)
- [How to make Bump Chart](https://youtu.be/K-weHCSQb58)
- [How to make Circle Packing](https://youtu.be/inm_fR-oykw)
- [How to make Treemap](https://youtu.be/W_MuNYWjhfc)
- [How to make Streamgraph](https://youtu.be/Iu8Me9QO8mg)
- [How to make Sunburst Diagram](https://youtu.be/knqimV7RVbI)
- [How to make Voronoi Diagram](https://youtu.be/I7nn29giVug)
- [How to make Hexagonal Binning](https://youtu.be/Q03sVDj32l4)
