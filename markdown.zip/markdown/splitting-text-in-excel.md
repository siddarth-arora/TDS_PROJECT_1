## Splitting Text in Excel

[![Convert text-to-columns in Excel](https://i.ytimg.com/vi_webp/fQeADnqiOAg/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

**Main Topic:**

The image depicts a tutorial on using the "Text to Columns" feature in a spreadsheet program (likely Microsoft Excel or a similar application).

**Content:**

*   **Spreadsheet Data:** The spreadsheet contains a list of names, likely politicians, along with their state and a voting decision ("Yea," "Nay," or "Not Voting").
*   **Text to Columns Wizard:** The core of the image is the "Convert Text to Columns Wizard." This tool is used to split text strings within a single column into multiple columns based on a delimiter (a character that separates the parts of the string).
*   **Wizard Steps:** The image shows the third step of the wizard.
*   **Column Data Format:** The wizard displays formatting options for the columns.

    *   *General*
    *   *Text*
    *   *Date*: DMY
    *   *Do not import column (skip)*
*   **Delimiter:** Delimiter input box (marked as *Other:*)

*   **Destination:** There's a field labeled "Destination: $A$1." This specifies where the split data will be placed in the spreadsheet (starting at cell A1).
*   **Preview:** There's a "Preview of selected data" section showing how the data will be split based on the chosen delimiter.
*   **Navigation Buttons:** The wizard has "Cancel," "< Back," "Next >," and "Finish" buttons for navigating the process.
](https://youtu.be/fQeADnqiOAg)

You'll learn how to transform a single-column data set into multiple, organized columns based on specific delimiters using the "Text to Columns" feature.

Here are links used in the video:

- [US Senate Legislation - Votes](https://www.senate.gov/legislative/votes_new.htm)
