## Regression with Excel

[![Regression with Excel](https://i.ytimg.com/vi_webp/AERQBMIHwXA/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content visible in the image:

**Main Topic:** Statistical Analysis, specifically Regression and ANOVA related to a topic involving "new cases".

**Key Elements:**

1.  **Dependent Variable:** "new\_cases\_per\_thousand"  (likely new COVID-19 cases per thousand people).

2.  **Independent Variables:** The model seems to be trying to predict new cases per thousand based on the following factors:
    *   "new\_tests" (number of new tests conducted)
    *   "new\_vacc" (number of new vaccinations)
    *   "stringency" (government stringency index, a measure of how strict the government is in its response to COVID-19)

3.  **Data and Analysis Sections:**

    *   **Standard/Observed Values:**  There are two numbers in columns B7 and B8, labeled Standard and Observed, with values 479.4514 and 460, respectively.
    *   **ANOVA Table:** An ANOVA (Analysis of Variance) table, which assesses the overall significance of the regression model. It shows the following:
        *   Source of Variation: Regression, Residual, Total
        *   Degrees of Freedom (df)
        *   Sum of Squares (SS)
        *   Mean Square (MS)
        *   F-statistic (F)
        *   Significance F (p-value for the overall model)

    *   **Regression Output:** A table showing the results of the multiple regression analysis, with the following columns for each independent variable (and the intercept):
        *   Coefficient
        *   Standard Error
        *   t Stat (t-statistic)
        *   P-value
        *   Lower 95% / Upper 95% (confidence intervals)
        *   Lower 95.0%/Upper 95.0% (confidence intervals)

**Formulas and Statistics**

The image doesn't show the formulas themselves, but it presents the results of various statistical calculations, as indicated by the headings in the ANOVA and Regression tables.
The output shows results from statistical functions, with indicators such as p-value, t-stat, ANOVA analysis of variation, and the F statistic.
**In summary**, the image presents statistical output related to a regression analysis attempting to model or explain the number of new COVID-19 cases per thousand people based on factors such as testing rates, vaccination rates, and the stringency of government interventions.
](https://youtu.be/AERQBMIHwXA)

You'll learn to perform regression analysis using Excel, covering:

- **Data Preparation**: Understanding the cleaned dataset and necessary columns for analysis.
- **Enabling the Tool**: How to enable the Data Analysis Tool Pack in Excel.
- **Types of Regression**: Differences between simple and multiple linear regression.
- **Setting Up Regression**: Steps to input dependent (new deaths) and independent variables (new cases, new tests, new vaccinations, stringency index) for the analysis.
- **Interpreting Output**: Reading the regression output, focusing on adjusted R-squared, significance value (F-test), and P-values.
- **Coefficient Interpretation**: Understanding the impact of each independent variable on the dependent variable, including scaling factors (per 1000 units).
- **Model Evaluation**: Evaluating the model based on significance values and understanding the implications of unexpected results (e.g., stringency index).
- **Further Analysis**: Recognizing the need for additional analysis when encountering unexpected or inconclusive results.

Here are the links used in the video:

- [Understand regression](https://www.khanacademy.org/math/ap-statistics/bivariate-data-ap/least-squares-regression/v/calculating-the-equation-of-a-regression-line)
- [COVID-19 vaccinations - Regression Excel file](https://docs.google.com/spreadsheets/d/1YZLb9ozhmc-8KQ7EaaTgs57QT6dHju5u/view#gid=242862119)
- [COVID-19 vaccinations - Regression Model 2 Excel file](https://docs.google.com/spreadsheets/d/1KAolaOQC-P_6gXaw3jgUc7GWKAHfOrsi/view#gid=824457557)
