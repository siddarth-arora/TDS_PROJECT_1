## Interactive Notebooks: Marimo

[Marimo](https://marimo.app/) is a new take on notebooks that solves some headaches of Jupyter. It runs cells reactively - when you change one cell, all dependent cells update automatically, just like a spreadsheet.

Marimo's cells can't be run out of order. This makes Marimo more reproducible and easier to debug, but requires a mental shift from the Jupyter/Colab way of working.

It also runs Python directly in the browser and is quite interactive. [Browse the gallery of examples](https://marimo.io/gallery). With a wide variety of interactive widgets, It's growing popular as an alternative to Streamlit for building data science web apps.

Common Operations:

```python
# Create new notebook
uvx marimo new

# Run notebook server
uvx marimo edit notebook.py

# Export to HTML
uvx marimo export notebook.py
```

Best Practices:

1. **Cell Dependencies**
   - Keep cells focused and atomic
   - Use clear variable names
   - Document data flow between cells
2. **Interactive Elements**

   ```python
   # Add interactive widgets
   slider = mo.ui.slider(1, 100)
   # Create dynamic Markdown
   mo.md(f"{slider} {"🟢" * slider.value}")
   ```

3. **Version Control**
   - Keep notebooks are Python files
   - Use Git to track changes
   - Publish on [marimo.app](https://marimo.app/) for collaboration

[!["marimo: an open-source reactive notebook for Python" - Akshay Agrawal (Nbpy2024)](https://i.ytimg.com/vi_webp/9R2cQygaoxQ/sddefault.webp)

> 📘 **Image Description:** Here's a description of the study-related content in the image:

**Main Topic:** The image appears to be related to machine learning, specifically image recognition or classification. It involves a dataset of handwritten digits.

**Content Breakdown:**

*   **Image Preview:** The heading "Here's a preview of the images you've selected" indicates that the images displayed at the top are a subset chosen from a larger dataset. The images are of handwritten digits, specifically the digit "2".

*   **Data Table:** The section "Here's all the data you've selected" displays data associated with these images in a tabular format. The table includes the following columns:

    *   **index:** The index or identifier for each image in the dataset.
    *   **x:** A numerical value labeled as "x". This could represent a coordinate, a feature extracted from the image, or another relevant attribute.
    *   **y:** A numerical value labeled as "y". Similar to "x", this could represent a coordinate or feature.
    *   **digit:** The actual digit represented in the image (the "label" in machine learning terms). The digit values are 8, 7, 6, and 3.

*   **Graphs:** Above the data table are bar graphs representing the data in each of the columns, except the y column.

*   **Code Execution Setting:** At the bottom, there are controls for "on startup: autorun" and "on cell change: autorun". This indicates that the content is displayed within a computational notebook environment (like Jupyter Notebook or a similar tool).

**Overall:**

The image shows a snapshot of a machine learning project dealing with handwritten digit recognition. The data includes the raw images, an index for each image, numerical features (likely extracted from the images), and the actual digit value. The environment shown is likely being used to explore and manipulate this data.
](https://youtu.be/9R2cQygaoxQ)
