## Serverless hosting: Vercel

<!--

Why Vercel? I evaluated from https://survey.stackoverflow.co/2024/technology#2-cloud-platforms

- AWS, Azure, Google Cloud are too complex for beginners
- Cloudflare (next most popular, widely admired) Python support is in beta
- Hetzner (most admired), Supabase (next most admired) do not have a serverless platform
- Fly.io (next most admired) does not have a free tier
- Heroku (used in previous terms) is the least admired
- Vercel is both popular, admired, growing, has a free plan, and a simple API

-->

Serverless platforms let you rent a single function instead of an entire machine. They're perfect for small web tools that _don't need to run all the time_. Here are some common real-life uses:

- A contact form that emails you when someone wants to hire you (runs for 2-3 seconds, a few times per day)
- A tool that converts uploaded photos to black and white (runs for 5-10 seconds when someone uploads a photo)
- A chatbot that answers basic questions about your business hours (runs for 1-2 seconds per question)
- A newsletter sign-up that adds emails to your mailing list (runs for 1 second per sign-up)
- A webhook that posts your Etsy sales to Discord (runs for 1 second whenever you make a sale)

You only pay when someone uses your tool, and the platform automatically handles busy periods. For example, if 100 people fill out your contact form at once, the platform creates 100 temporary copies of your code to handle them all. When they're done, these copies disappear. It's cheaper than running a full-time server because you're not paying for the time when no one is using your tool - most tools are idle 95% of the time!

Rather than writing a full program, serverless platforms let you write functions. These functions are called via HTTP requests. They run in a cloud environment and are scaled up and down automatically. But this means you write programs in a different style. For example:

- You can't `pip install` packages - you have to use `requirements.txt`
- You can't read or write files from the file system - you can only use APIs.
- You can't run commands (e.g. `subprocess.run()`)

[Vercel](https://vercel.com/) is a cloud platform optimized for frontend frameworks and serverless functions. Vercel is tightly integrated with GitHub. Pushing to your repository automatically triggers new deployments.

Here's a [quickstart](https://vercel.com/docs/functions/runtimes/python). [Sign-up with Vercel](https://vercel.com/signup). Create an empty `git` repo with this `api/index.py` file.

To deploy a FastAPI app, add a `requirements.txt` file with `fastapi` as a dependency.

```text
fastapi
```

Add your FastAPI code to a file, e.g. `main.py`.

```python
# main.py
from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "Hello, World!"}
```

Add a `vercel.json` file to the root of your repository.

```json
{
  "builds": [{ "src": "main.py", "use": "@vercel/python" }],
  "routes": [{ "src": "/(.*)", "dest": "main.py" }]
}
```

On the command line, run:

- `npx vercel` to deploy a test version
- `npx vercel --prod` to deploy to production

**Environment Variables**. Use `npx vercel env add` to add environment variables. In your code, use `os.environ.get('SECRET_KEY')` to access them.

### Videos

[![Vercel Product Walkthrough](https://i.ytimg.com/vi_webp/sPmat30SE4k/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

*   **Main Topic:** The image focuses on the web development platform Vercel.
*   **Headers/Navigation:** The following headers and navigational elements are visible, representing key areas or functionalities of the platform:

    *   Vercel (Logo/Brand)
    *   Git Provider (Indicates integration with Git)
    *   Acme Enterprise (Likely an account/organization name)
    *   Projects
    *   Integrations
    *   Activity
    *   Domains
    *   Usage
    *   Settings
    *   Search...
    *   Feedback
    *   Blog

*   **Project View:** A project called "vercel-times" is displayed, with the URL "verceltimes.com" associated with it.

*   **Update Log:** A recent commit log message is shown for the "vercel-times" project:

    *   "update img src"
    *   "From change-logo"
    *   "2 min ago via" (GitHub logo)

*   **Framework/Technology:** Another project (or part of the previous project) is shown, with "nextjs.org" which is a react framework.

*   **Documentation:** Another commit log message is shown for the "vercel-times" project:

    *   "Updated docs on layout"
    *   "From locs"
    *   "3 min ago via" (GitHub logo)

**In summary:** The image is a screenshot of the Vercel platform interface, likely being used for web development. It showcases project management, Git integration, monitoring activity, and navigating various settings within the platform. The specific example shows a project called "vercel-times" being developed with the Next.js framework, with recent commits related to updating images and documentation.
](https://youtu.be/sPmat30SE4k)

[![Deploy FastAPI on Vercel | Quick and Easy Tutorial](https://i.ytimg.com/vi_webp/8R-cetf_sZ4/sddefault.webp)

> 📘 **Image Description:** Based on the image, here's the study-related content I can identify:

*   **Main Topic:** "DEPLOY FAST", suggesting a topic related to software deployment.
*   **Visual Elements:** The logo in the background and the triangle suggest the technology might be related to Vercel.
*   **Contextual Information:** The background contains a matrix of 0s and 1s, which may mean that the material is related to binary.
](https://youtu.be/8R-cetf_sZ4)
