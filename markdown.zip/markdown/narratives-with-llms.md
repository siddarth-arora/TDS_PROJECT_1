## Narratives with LLMs

#TODO
