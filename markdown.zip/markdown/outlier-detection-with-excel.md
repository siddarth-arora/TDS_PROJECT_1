## Outlier Detection with Excel

[![Outlier detection with Excel](https://i.ytimg.com/vi_webp/sUTJb0F9eBw/sddefault.webp)

> 📘 **Image Description:** Here's a description of the study-related content visible in the image:

*   **Software:** The image shows Microsoft Excel.

*   **Main Topic:** Based on the formula being used, the main topic is statistics, specifically Quartiles.

*   **Formula:** The Excel formula being used is `=QUARTILE.EXC(A2:A844,3)`.
    *   `QUARTILE.EXC`:  This is an Excel function that returns the quartile of a data set, excluding the minimum and maximum values.
    *   `A2:A844`:  This is the range of cells (from A2 to A844) that contains the data set for which the quartile is being calculated.
    *   `3`: This indicates that the third quartile (Q3) is being calculated.  The `quart` argument can be 1, 2, 3, or 4, representing the first, second (median), third, or fourth quartile, respectively.
](https://youtu.be/sUTJb0F9eBw)

You'll learn how to identify and handle outliers in data using Excel, covering:

- **Understanding Outliers**: Definition of outliers and their impact on statistical analysis.
- **Calculating Quartiles**: Using Excel formulas to calculate Q1 (first quartile) and Q3 (third quartile).
- **Interquartile Range (IQR)**: Finding the IQR by subtracting Q1 from Q3.
- **Determining Bounds**: Calculating lower and upper bounds using 1.5 times the IQR.
- **Identifying Outliers**: Using Excel functions to determine if data points fall outside the calculated bounds.
- **Visualizing Data**: Creating box plots to visualize outliers and data distribution.
- **Handling Outliers**: Deciding whether to exclude or keep outliers based on their impact on analysis.

Here are the links used in the video:

- [Understand distributions and outliers](https://www.khanacademy.org/math/ap-statistics/quantitative-data-ap/xfb5d8e68:describing-distribution-quant/v/classifying-distributions)
- [COVID-19 vaccinations data - Excel](https://docs.google.com/spreadsheets/d/1_vQF2i5ubKmHQMBqoTwsu6AlevWsQtTD/view#gid=790744269)
