## Actor Network Visualization

Find the shortest path between Govinda & Angelina Jolie using IMDb data using Python: [networkx](https://pypi.org/project/networkx/) or [scikit-network](https://pypi.org/project/scikit-network).

[![Jolie No. 1](https://i.ytimg.com/vi_webp/lcwMsPxPIjc/sddefault.webp)

> 📘 **Image Description:** There appears to be no study-related content in the image. The text extracted from the image is as follows:

"GOVINDA DECLINES 'AVATAR' FILM BY JAMES CAMERON
Claims he suggested the title"

This text refers to a news story or headline.  There are no headings, formulas, or identifiable topics related to academic study.
](https://youtu.be/lcwMsPxPIjc)

- [Notebook: How this video was created](https://github.com/sanand0/jolie-no-1/blob/master/jolie-no-1.ipynb)
- [The data used to visualize the network](https://github.com/sanand0/jolie-no-1/blob/master/imdb-actor-pairing.ipynb)
- [The shortest path between actors](https://github.com/sanand0/jolie-no-1/blob/master/shortest-path.ipynb)
- [IMDB data](https://developer.imdb.com/non-commercial-datasets/)
- [Codebase](https://github.com/sanand0/jolie-no-1)
