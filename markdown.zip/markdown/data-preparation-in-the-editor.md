## Data Preparation in the Editor

[![Data preparation in the editor](https://i.ytimg.com/vi_webp/99lYu43L9uM/sddefault.webp)

> 📘 **Image Description:** Here's a description of the study-related content in the image:

*   **Main Topic:** The image displays a JSON file named "city-product-sales.json." The content appears to be sales data for different products in various cities.

*   **Structure:** The JSON data is structured as an array of objects. Each object represents the sales information for a specific city and includes the following keys:
    *   `"city"`: The name of the city.
    *   `"product"`: The name of the product sold.
    *   `"sales"`: The sales quantity or amount.

*   **Example Data:** The image shows data for several cities:
    *   Rio de Janeiro (Bananas, sales: 82)
    *   Mannila (Apples, sales: 30)
    *   Cairo (Bananas, sales: 29)
    *   Lagos (Flour, sales: 72)

*   **Headings:** The keys in the JSON objects effectively act as headings: "city", "product", and "sales".

*   **Formulas:** There are no formulas present in the image. It's raw data.

The user is searching within the file, looking for instances of the string “city”.
](https://youtu.be/99lYu43L9uM)

You'll learn how to use a text editor [Visual Studio Code](https://code.visualstudio.com/) to process and clean data, covering:

- **Format** JSON files
- **Find all** and multiple cursors to extract specific fields
- **Sort** lines
- **Delete duplicate** lines
- **Replace** text with multiple cursors

Here are the links used in the video:

- [City-wise product sales JSON](https://drive.google.com/file/d/1VEnKChf4i04iKsQfw0MwoJlfkOBGQ65B/view?usp=drive_link)
