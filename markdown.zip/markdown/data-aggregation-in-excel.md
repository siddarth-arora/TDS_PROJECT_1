## Data Aggregation in Excel

[![Data aggregation in Excel](https://i.ytimg.com/vi_webp/NkpT0dDU8Y4/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

**Main Topic:**

The image appears to show data analysis related to the spread of COVID-19 in Brazil.

**Spreadsheet Headings (Columns):**

*   **iso_code:**  Likely the ISO country code (BRA for Brazil).
*   **location:**  The country (Brazil).
*   **date:** Date of the observation (e.g., 26-02-20, 27-02-20).
*   **week:** Week number.
*   **month:** Month of the observation (Feb, Mar).
*   **year:** Year of the observation (2020).
*   **total_cases:** Total number of confirmed cases (cumulative).
*   **new_cases:** New confirmed cases for that day.
*   **total_cases_per_million:** Total cases per million population.
*   **new_cases_per_million:** New cases per million population.
*   **stringency_index:** Government response stringency index (higher values indicate stricter policies).
*   **hospital_beds_per_thousand:** Number of hospital beds per 1000 people
*   **life_expectancy**

**Data:**

The data consists of daily records from February and March 2020 showing the number of total cases, new cases, and related metrics for Brazil.

**Formatting Rule Window:**

The "New Formatting Rule" window is open in Excel.  It indicates that the user is applying conditional formatting:

*   The formatting is being applied based on cell values.
*   The selected format style is "3-Color Scale," allowing the user to highlight cell values with a color gradient.
*   The lowest value will be colored green, the midpoint (50th percentile) will be colored yellow, and the highest value will be colored red.

**Formulas:**

There are no explicit formulas visible in the image. However, the derived columns like "total_cases_per_million" and "new_cases_per_million" would have been calculated using formulas based on the total/new cases and the population of Brazil.

**Analysis:**

The user is visualizing the trend of COVID-19 cases. The color-coding will help to easily identify the periods with the lowest, medium and highest rates of infection.
](https://youtu.be/NkpT0dDU8Y4)

You'll learn data aggregation and visualization techniques in Excel, covering:

- **Data Cleanup**: Remove empty columns and rows with missing values.
- **Creating Excel Tables**: Convert raw data into tables for easier manipulation and formula application.
- **Date Manipulation**: Extract week, month, and year from date columns using Excel functions (WEEKNUM, TEXT).
- **Color Scales**: Apply color scales to visualize clusters and trends in data over time.
- **Pivot Tables**: Create pivot tables to aggregate data by location and date, summarizing values weekly and monthly.
- **Sparklines**: Use sparklines to visualize trends within pivot tables, making data patterns more apparent.
- **Data Bars**: Implement data bars for graphical illustrations of numerical columns, showing trends and waves.

Here are links used in the video:

- [COVID-19 data Excel file - raw data](https://docs.google.com/spreadsheets/d/14HLgSmME95q--6lcBv9pUstqHL183wTd/view)
