## Scraping IMDb with JavaScript

[![Scraping the IMDb with Browser JavaScript](https://i.ytimg.com/vi_webp/YVIKZqZIcCo/sddefault.webp)

> 📘 **Image Description:** Here's a breakdown of the study-related content in the image:

**Main Topic:** Troubleshooting JavaScript or web development code related to selecting and extracting text content from HTML elements.  The specific problem is likely that the `.text` property on an element selected using `querySelectorAll` is not working as expected.

**Code Snippet:**

*   `item.querySelectorAll(".cli-title-metadata-item:nth-child(1)").text`

**Issues and Solutions (numbered points):**

1.  **No Matching Elements:** The query selector isn't finding any elements that match the specified CSS selector (`.cli-title-metadata-item:nth-child(1)`) within the `item` element. This can be due to:
    *   Incorrect class name or structure
    *   Elements being dynamically loaded after the code executes.
2.  **Wrong Pseudo-Class:** The `:nth-child(1)` pseudo-class may be inappropriate.  It might be selecting the wrong element if it isn't the first child of its parent. Suggests double-checking the element's position in the DOM.
3.  **Typo in Class Name:** Suggests verifying that there are no typos in the class name `.cli-title-metadata-item`.
4.  **Incorrect Usage of `querySelectorAll`:** Explains that `querySelectorAll` returns a `NodeList`, not a single element. To get the text of the *first* element, you need to access it using index `[0]` (e.g., `[0].text`).
5.  **Missing Text Property:** The suggestion is that the correct properties to access the text content of an element are `.textContent` or `.innerText`, not just `.text`.

In summary, the content focuses on common errors developers face when trying to select specific elements and extract their text using JavaScript in a web development context.
](https://youtu.be/YVIKZqZIcCo)

You'll learn how to scrape the [IMDb Top 250 movies](https://www.imdb.com/chart/top) directly in the browser using JavaScript on the Chrome DevTools, covering:

- **Access Developer Tools**: Use F12 or right-click > Inspect to open developer tools in Chrome or Edge.
- **Inspect Elements**: Identify and inspect HTML elements using the Elements tab.
- **Query Selectors**: Use `document.querySelectorAll` and `document.querySelector` to find elements by CSS class.
- **Extract Text Content**: Retrieve text content from elements using JavaScript.
- **Functional Programming**: Apply [map](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/map)
  and [arrow functions](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/Arrow_functions)
  for concise data processing.
- **Data Structuring**: Collect and format data into an array of arrays.
- **Copying Data**: Use the copy function to transfer data to the clipboard.
- **Convert to Spreadsheet**: Use online tools to convert JSON data to CSV or Excel format.
- **Text Manipulation**: Perform text splitting and cleaning in Excel for final data formatting.

Here are links and references:

- [IMDB Top 250 movies](https://www.imdb.com/chart/top/)
- [Learn about Chrome Devtools](https://developer.chrome.com/docs/devtools/overview/)
