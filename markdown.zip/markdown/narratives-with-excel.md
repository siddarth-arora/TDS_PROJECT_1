## Narratives with Excel

[![Narratives with Excel](https://i.ytimg.com/vi_webp/CRNJerr3pI4/sddefault.webp)

> 📘 **Image Description:** Here's a description of the study-related content in the image:

**Main Topic:**  Analysis of COVID-19 case trends.

**Headings:**

*   **DATA STRUCTURE:**  This section contains the raw data.
*   **ANALYSIS METRICS:** This section contains calculated statistical values.
*   **CALIBRATION:** This appears to be a section where numerical values are mapped to qualitative labels or categories describing the trend.
*   **ENTITIES:**

**Data and Information:**

*   **Time (or Month):** Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec are listed.
*   **Value:** A column of numerical values associated with each month. These likely represent the number of COVID-19 cases.
*   **Location:** India is selected in a dropdown.
*   **Row Labels / Sum of new\_cases:**  A table showing the sum of new cases for each month.
*   **Grand Total:** 30837222

**Analysis Metrics:**

*   **Slope:** -95455.393

**Calibration:**

*   A table relating numeric values (presumably of the slope) to descriptive labels (e.g., "totally collapsing," "collapsing," "de-growing," etc.). The values are followed by the letter N which likely represents that these are numerical values.

**Entities:**

*   Jan, Feb
*   New COVID case

**Chart:**

*   A bar chart titled "New covid cases are collapsing" showing new COVID cases over 12 periods (presumably months).
*   A trendline is overlaid on the bar chart, with the equation displayed as "y = 95455x + [Number, possibly 33106]" and "R^2 = [Number, possibly 0.3361]"

**Additional Numerical Data:**

*   A list of values associated with the countries India, Brazil, Europe, Iran, Japan.

**Overall:**

The content focuses on analyzing the trend of COVID-19 cases over time. The data is structured chronologically, and analysis involves calculating the slope of the trendline and associating it with descriptive labels.
](https://youtu.be/CRNJerr3pI4)

- [Sample Excel](https://docs.google.com/spreadsheets/d/1Htmr5ar0ZX2nYW8Xerr9OaLJl3zS0gxY/view#gid=171350107)
